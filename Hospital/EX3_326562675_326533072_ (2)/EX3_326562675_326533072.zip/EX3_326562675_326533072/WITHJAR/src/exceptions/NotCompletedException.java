package exceptions;

public class NotCompletedException extends Exception{
	private static final long serialVersionUID = 1L;

	public NotCompletedException(String message) {
		super(message);
	}


}
