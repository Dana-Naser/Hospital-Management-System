package exceptions;

public class NonNumericInputException extends Exception {
	private static final long serialVersionUID = 1L;

	public NonNumericInputException(String message) {
        super(message);
    }

}
