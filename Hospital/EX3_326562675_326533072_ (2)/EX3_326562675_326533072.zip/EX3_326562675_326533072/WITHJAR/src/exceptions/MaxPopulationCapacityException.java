

package exceptions;

public class MaxPopulationCapacityException extends Exception {
    private final int maxCapacity;

    public MaxPopulationCapacityException(String message, int maxCapacity) {
        super(message);
        this.maxCapacity = maxCapacity;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }
}

