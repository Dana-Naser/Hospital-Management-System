package enums;

public enum BiologicalSex {
	M, F
}
