//Dana Naser-326533072
//Layan Shawahny-326562675
package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import com.toedter.calendar.JDateChooser;
import control.Hospital;
import model.Patient;
import model.Visit;

public class AddVisit extends JFrame implements Serializable{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField numberTxt;
    private transient JDateChooser startDateChooser;
    private transient JDateChooser endDateChooser;
    private SimpleDateFormat dateFormat;

    public AddVisit() {
        setTitle("Add Visit");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 946, 498);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Background color
        contentPane.setBackground(SystemColor.activeCaption);
        
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
        
        
        // Title Label
        JLabel titleLabel = new JLabel("Add Visit");
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 35));
        titleLabel.setForeground(SystemColor.inactiveCaptionBorder);
        titleLabel.setBounds(417, 23, 144, 42);
        contentPane.add(titleLabel);

        // Number Label
        JLabel numberLabel = new JLabel("Number:");
        numberLabel.setForeground(SystemColor.inactiveCaptionBorder);
        numberLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        numberLabel.setBounds(354, 100, 89, 25);
        contentPane.add(numberLabel);

        // Patient Label
        JLabel patientLabel = new JLabel("Patient:");
        patientLabel.setForeground(SystemColor.inactiveCaptionBorder);
        patientLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        patientLabel.setBounds(354, 146, 102, 30);
        contentPane.add(patientLabel);

        // Start Date Label
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setForeground(SystemColor.inactiveCaptionBorder);
        startDateLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        startDateLabel.setBounds(354, 211, 132, 25);
        contentPane.add(startDateLabel);

        // End Date Label
        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setForeground(SystemColor.inactiveCaptionBorder);
        endDateLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        endDateLabel.setBounds(354, 264, 118, 25);
        contentPane.add(endDateLabel);

        // Number Text Field
        numberTxt = new JTextField();
        numberTxt.setBounds(490, 101, 185, 30);
        contentPane.add(numberTxt);
        numberTxt.setColumns(10);

        // Date Format
        dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // Patient JComboBox
        JComboBox<Integer> patientComboBox = new JComboBox<>();
        patientComboBox.setBackground(SystemColor.window);
        patientComboBox.setBounds(490, 150, 185, 30);
        contentPane.add(patientComboBox);

        // Populate the JComboBox with patient IDs
        for (Patient p : Hospital.getInstance().getPatients().values()) {
            patientComboBox.addItem(p.getId());
        }

        // Patient JComboBox Action Listener
        patientComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isEnabled = patientComboBox.getSelectedIndex() != -1;
                numberTxt.setEnabled(isEnabled);
                startDateChooser.setEnabled(isEnabled);
                endDateChooser.setEnabled(isEnabled);
            }
        });
     // Add back button
        JButton backButton = new JButton("NURSE Main");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        backButton.setBackground(SystemColor.activeCaption);
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setBounds(159, 420, 139, 35);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new NurseMainpage().setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(backButton);
        
        JButton btnNewButton = new JButton("ADMIN Main");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton.setBackground(SystemColor.activeCaption);
        btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
        btnNewButton.setBounds(159, 420, 139, 35);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 playSound("ss1.wav");
                 new Admin().setVisible(true);
                 setVisible(false);
        		
        	}
        });
        btnNewButton.setBounds(10, 420, 124, 33);
        contentPane.add(btnNewButton);
        setVisible(true); // Make sure the frame is visible
    


    

        // Add Button
        JButton btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 25));
        btnAdd.setBackground(SystemColor.menu);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setBounds(434, 312, 118, 42);
        btnAdd.setFocusPainted(false);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                createVisit(patientComboBox);
            }
        });
        contentPane.add(btnAdd);

       
      

        // Date Choosers
        startDateChooser = new JDateChooser();
        startDateChooser.setBounds(490, 201, 185, 35);
        contentPane.add(startDateChooser);

        endDateChooser = new JDateChooser();
        endDateChooser.setBounds(490, 250, 185, 36);
        contentPane.add(endDateChooser);
    }

    private void createVisit(JComboBox<Integer> patientComboBox) {
        try {
            // Check if all fields are filled
            if (numberTxt.getText().isEmpty() || startDateChooser.getDate() == null || endDateChooser.getDate() == null
                    || patientComboBox.getSelectedIndex() == -1) {
                throw new Exception("Complete all the information, please.");
            }

            // Parse input data
            int number = Integer.parseInt(numberTxt.getText());
            Date startDate = startDateChooser.getDate();
            Date endDate = endDateChooser.getDate();
            int patientId = (Integer) patientComboBox.getSelectedItem();

            // Create and add the visit
            Visit visit = new Visit(number, Hospital.getInstance().getRealPatient(patientId), startDate, endDate);
            if (Hospital.getInstance().addVisit(visit)) {
                JOptionPane.showMessageDialog(this, "Visit added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add the visit.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Please enter the dates in the format yyyy-MM-dd.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for the visit number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        numberTxt.setText("");
        startDateChooser.setDate(null);
        endDateChooser.setDate(null);
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

}
