package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.MedicalProblem;
import model.Treatment;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.sound.sampled.*;
import java.io.IOException;
import java.io.Serializable;


public class AddTreatmenttoMedProblem extends JFrame implements Serializable
{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<MedicalProblem> medicalProblemComboBox;
    private JComboBox<Treatment> treatmentComboBox;
    private Clip clip;

    public AddTreatmenttoMedProblem() {
        setTitle("Add Treatment to Medical Problem");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1009, 729);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/pic/LOgoEnd.png")); // Ensure correct path
        Image logoImage = logoIcon.getImage().getScaledInstance(175, 70, Image.SCALE_SMOOTH); // Scale image
        logoLabel.setIcon(new ImageIcon(logoImage));
        logoLabel.setBounds(20, 23, 175, 70);
        contentPane.add(logoLabel);

        // Title
        JLabel lblTitle = new JLabel("Add Treatment to Medical Problem", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 30));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(205, 10, 503, 35);
        contentPane.add(lblTitle);

        // Main button to navigate back to the main page
        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.activeCaption);
        btnMain.setForeground(SystemColor.inactiveCaptionBorder);
        btnMain.setBounds(796, 23, 122, 35);
        btnMain.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                DoctorMainpage mainPage = new DoctorMainpage();
                mainPage.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnMain);

        // Medical Problem Label
        JLabel lblMedicalProblem = new JLabel("Select Medical Problem:");
        lblMedicalProblem.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        lblMedicalProblem.setForeground(SystemColor.inactiveCaptionBorder);
        lblMedicalProblem.setBounds(100, 100, 250, 30);
        contentPane.add(lblMedicalProblem);

        // Medical Problem ComboBox
        medicalProblemComboBox = new JComboBox<>();
        medicalProblemComboBox.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        medicalProblemComboBox.setBounds(350, 100, 300, 30);
        contentPane.add(medicalProblemComboBox);

        // Treatment Label
        JLabel lblTreatment = new JLabel("Select Treatment:");
        lblTreatment.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        lblTreatment.setForeground(SystemColor.inactiveCaptionBorder);
        lblTreatment.setBounds(100, 200, 250, 30);
        contentPane.add(lblTreatment);

        // Treatment ComboBox
        treatmentComboBox = new JComboBox<>();
        treatmentComboBox.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        treatmentComboBox.setBounds(350, 200, 300, 30);
        contentPane.add(treatmentComboBox);

        // Load medical problems and treatments into the combo boxes
        loadMedicalProblems();
        loadTreatments();

        // Add Treatment Button
        JButton btnAddTreatment = new JButton("Add Treatment");
        btnAddTreatment.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        btnAddTreatment.setBackground(SystemColor.text);
        btnAddTreatment.setForeground(SystemColor.activeCaption);
        btnAddTreatment.setBounds(350, 300, 200, 40);
        btnAddTreatment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                addTreatmentToMedicalProblem();
            }
        });
        contentPane.add(btnAddTreatment);

        setVisible(true);
    }

    private void loadMedicalProblems() {
        for (MedicalProblem mp : Hospital.getInstance().getMedicalProblems().values()) {
            medicalProblemComboBox.addItem(mp);
        }
    }

    private void loadTreatments() {
        for (Treatment treatment : Hospital.getInstance().getTreatments().values()) {
            treatmentComboBox.addItem(treatment);
        }
    }

    private void addTreatmentToMedicalProblem() {
        MedicalProblem selectedMedicalProblem = (MedicalProblem) medicalProblemComboBox.getSelectedItem();
        Treatment selectedTreatment = (Treatment) treatmentComboBox.getSelectedItem();

        if (selectedMedicalProblem != null && selectedTreatment != null) {
            try {
                if (selectedMedicalProblem.addTreatment(selectedTreatment)) {
                    JOptionPane.showMessageDialog(this, "Treatment added successfully to the medical problem!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    DoctorMainpage doctorMainpage = new DoctorMainpage();
                    doctorMainpage.showAllData(); // Show the updated data after adding the treatment
                } else {
                    JOptionPane.showMessageDialog(this, "Treatment already exists in the medical problem!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select both a medical problem and a treatment.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                new AddTreatmenttoMedProblem().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
