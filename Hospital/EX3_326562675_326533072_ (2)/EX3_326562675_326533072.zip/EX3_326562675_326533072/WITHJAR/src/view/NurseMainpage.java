package view;

import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.Patient;
import model.Treatment;
import model.Visit;
import model.Medication;
import model.Disease;
import model.Fracture;
import model.Injury;
import model.MedicalProblem;
import control.Hospital;

public class NurseMainpage extends JFrame  implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Clip clip;
    private int minVisits;

    public static void main(String[] args) {
        NurseMainpage frame = new NurseMainpage();
        frame.setVisible(true);
    }
    public NurseMainpage(int minVisits) {
        this.minVisits = minVisits; // Initialize minVisits in the constructor
    }

    public NurseMainpage() {
        setTitle("Nurse Main Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1013, 728);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption); // Matching background color
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/pic/LOgoEnd.png")); // Ensure correct path
        Image logoImage = logoIcon.getImage().getScaledInstance(175, 70, Image.SCALE_SMOOTH); // Scale image
        logoLabel.setIcon(new ImageIcon(logoImage));
        logoLabel.setBounds(10, 11, 175, 70); // Adjust bounds as needed
        contentPane.add(logoLabel);

        // Title
        JLabel lblTitle = new JLabel("Hi Nurse :)", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 45));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(250, 30, 500, 60);
        contentPane.add(lblTitle);

        // Edit Information Button
        JButton editInfoBtn = new JButton("SHOW/EDIT MY INFORMATION");
        editInfoBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                 		ShowMyData s = new ShowMyData();
                 		s.setVisible(true);
                 	}
        });        editInfoBtn.setFont(new Font("Tahoma", Font.PLAIN, 22));
        editInfoBtn.setBounds(100, 150, 563, 60);
        editInfoBtn.setBackground(SystemColor.text);
        editInfoBtn.setForeground(SystemColor.activeCaption);
        editInfoBtn.addActionListener(e -> {
            playSound("ss1.wav");
            // Action for Edit Information button
        });
        contentPane.add(editInfoBtn);

        // Add Patient Button
        JButton addPatientBtn = new JButton("Add Patient");
        addPatientBtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        addPatientBtn.setBounds(100, 230, 563, 50);
        addPatientBtn.setBackground(SystemColor.text);
        addPatientBtn.setForeground(SystemColor.activeCaption);
        addPatientBtn.addActionListener(e -> {
            playSound("ss1.wav");
            AddPatient a = new AddPatient();
            a.setVisible(true);
            setVisible(false);
        });
        contentPane.add(addPatientBtn);
        
        
        
        JButton btnNewButton_2 = new JButton("VISITS BEFORE DATE\r\n");
        btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
        btnNewButton_2.setForeground(SystemColor.inactiveCaption);
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		howmanyvisitsbefore b = new	howmanyvisitsbefore();
        		b.setVisible(true);
        		
        	}
        });
        btnNewButton_2.setBounds(448, 467, 215, 50);
        contentPane.add(btnNewButton_2);
        
        JButton btnNewButton_3 = new JButton("COUNT MEDICATION");
        btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_3.setForeground(SystemColor.inactiveCaption);
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		countmedication C = new countmedication();
        		C.setVisible(true);
        	}
        });
        btnNewButton_3.setBounds(100, 465, 221, 52);
        contentPane.add(btnNewButton_3);
        
        JButton btnNewButton_4 = new JButton("INFO");
        btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_4.setForeground(SystemColor.inactiveCaption);
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Informations i = new Informations();
        		i.setVisible(true);
        	}
        });
        btnNewButton_4.setBounds(331, 466, 97, 50);
        contentPane.add(btnNewButton_4);

        setVisible(true);
    

        // Add Visit Button
        JButton addVisitBtn = new JButton("Add Visit");
        addVisitBtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        addVisitBtn.setBounds(100, 310, 563, 50);
        addVisitBtn.setBackground(SystemColor.text);
        addVisitBtn.setForeground(SystemColor.activeCaption);
        addVisitBtn.addActionListener(e -> {
            playSound("ss1.wav");
            AddVisit a = new AddVisit();
            a.setVisible(true);
            setVisible(false);
        });
        contentPane.add(addVisitBtn);

        // View Data Button
        JButton viewDataBtn = new JButton("Show All Data");
        viewDataBtn.setFont(new Font("Tahoma", Font.PLAIN, 22));
        viewDataBtn.setBounds(100, 390, 563, 50);
        viewDataBtn.setBackground(SystemColor.text);
        viewDataBtn.setForeground(SystemColor.activeCaption);
        viewDataBtn.addActionListener(e -> {
            playSound("ss1.wav");
            showAllData();
        });
        contentPane.add(viewDataBtn);
        

        // Logout Button
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("Tahoma", Font.BOLD, 20));
        logoutBtn.setBounds(850, 20, 120, 40);
        logoutBtn.setBackground(SystemColor.inactiveCaption);
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder());
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> {
            playSound("ss1.wav");
            setVisible(false);
            new login().setVisible(true);
        });
        contentPane.add(logoutBtn);

        setVisible(true);
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

   

    public void showAllData() {
        StringBuilder data = new StringBuilder();

        data.append("\nPatients:\n");
        List<Patient> sortedPatients = new ArrayList<>(Hospital.getInstance().getPatients().values());
        Collections.sort(sortedPatients, Comparator.comparing(Patient::getId)); // Sorting by ID

        for (Patient patient : sortedPatients) {
            data.append(patient).append("\n");
        }

        data.append("\nVisits:\n");
        List<Visit> sortedVisits = new ArrayList<>(Hospital.getInstance().getVisits().values());
        Collections.sort(sortedVisits, Comparator.comparing(Visit::getNumber)); // Sorting visits by number

        for (Visit visit : sortedVisits) {
            data.append(visit).append("\n");
        }

        data.append("\nTreatments:\n");
        for (Treatment treatment : Hospital.getInstance().getTreatments().values()) {
            data.append(treatment).append("\n");
            data.append("  Medications: \n");
            for (Medication medication : treatment.getMedicationsList()) {
                data.append("    ").append(medication).append("\n");
            }
        }

        data.append("\nMedications:\n");
        for (Medication medication : Hospital.getInstance().getMedications().values()) {
            data.append(medication).append("\n");
        }

        data.append("\nInjuries:\n");
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problem instanceof Injury) {
                data.append(problem).append("\n");
            }
        }

        data.append("\nDiseases:\n");
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problem instanceof Disease) {
                data.append(problem).append("\n");
            }
        }

        data.append("\nFractures:\n");
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problem instanceof Fracture) {
                data.append(problem).append("\n");
            }
        }

        JTextArea textArea = new JTextArea(data.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        JOptionPane.showMessageDialog(this, scrollPane, "View All Data", JOptionPane.INFORMATION_MESSAGE);
    }
}

