package view;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.MedicalProblem;
import model.Treatment;
import model.Visit;

public class AddMedProWTtoVISIT extends JFrame  implements Serializable
{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<Visit> visitComboBox;
    private JComboBox<MedicalProblem> medicalProblemComboBox;
    private JComboBox<Treatment> treatmentComboBox;
    private Clip clip;

    public AddMedProWTtoVISIT() {
        setTitle("Add Medical Problem and Treatment to Visit");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 450); // Adjust frame size as needed
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        // Title
        JLabel lblTitle = new JLabel("Add Medical Problem and Treatment to Visit", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 25));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(212, 11, 598, 40); // Adjusted bounds to account for logo space
        contentPane.add(lblTitle);

        // Visit ComboBox
        JLabel lblVisit = new JLabel("Select Visit:");
        lblVisit.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblVisit.setForeground(SystemColor.inactiveCaptionBorder);
        lblVisit.setBounds(50, 100, 200, 30);
        contentPane.add(lblVisit);

        visitComboBox = new JComboBox<>();
        visitComboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
        visitComboBox.setBounds(250, 100, 385, 30);
        contentPane.add(visitComboBox);

        // Medical Problem ComboBox
        JLabel lblMedicalProblem = new JLabel("Select Medical Problem:");
        lblMedicalProblem.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblMedicalProblem.setForeground(SystemColor.inactiveCaptionBorder);
        lblMedicalProblem.setBounds(50, 150, 200, 30);
        contentPane.add(lblMedicalProblem);

        medicalProblemComboBox = new JComboBox<>();
        medicalProblemComboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
        medicalProblemComboBox.setBounds(250, 150, 385, 30);
        contentPane.add(medicalProblemComboBox);

        // Treatment ComboBox
        JLabel lblTreatment = new JLabel("Select Treatment:");
        lblTreatment.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblTreatment.setForeground(SystemColor.inactiveCaptionBorder);
        lblTreatment.setBounds(50, 200, 200, 30);
        contentPane.add(lblTreatment);

        treatmentComboBox = new JComboBox<>();
        treatmentComboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
        treatmentComboBox.setBounds(250, 200, 385, 30);
        contentPane.add(treatmentComboBox);

        // Add Button
        JButton btnAdd = new JButton("Add to Visit");
        btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAdd.setBackground(SystemColor.text);
        btnAdd.setForeground(SystemColor.activeCaption);
        btnAdd.setBounds(250, 290, 150, 40);
        btnAdd.addActionListener(e -> {
            playSound("ss1.wav");
            addMedProWTtoVisit();
        });
        contentPane.add(btnAdd);

        // Back to Main Button
        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.activeCaption);
        btnMain.setForeground(SystemColor.inactiveCaptionBorder);
        btnMain.setBounds(420, 290, 114, 40);
        btnMain.addActionListener(e -> {
            playSound("ss1.wav");
            new DoctorMainpage().setVisible(true);
            setVisible(false);
        });
        contentPane.add(btnMain);

        // Load visits, medical problems, and treatments into the combo boxes
        loadVisits();
        loadMedicalProblems();
        loadTreatments();
    }

    private void loadVisits() {
        for (Visit visit : Hospital.getInstance().getVisits().values()) {
            visitComboBox.addItem(visit);
        }
    }

    private void loadMedicalProblems() {
        for (MedicalProblem medicalProblem : Hospital.getInstance().getMedicalProblems().values()) {
            medicalProblemComboBox.addItem(medicalProblem);
        }
    }

    private void loadTreatments() {
        for (Treatment treatment : Hospital.getInstance().getTreatments().values()) {
            treatmentComboBox.addItem(treatment);
        }
    }

    private void addMedProWTtoVisit() {
        Visit selectedVisit = (Visit) visitComboBox.getSelectedItem();
        MedicalProblem selectedMedicalProblem = (MedicalProblem) medicalProblemComboBox.getSelectedItem();
        Treatment selectedTreatment = (Treatment) treatmentComboBox.getSelectedItem();

        if (selectedVisit != null && selectedMedicalProblem != null && selectedTreatment != null) {
            try {
                selectedVisit.addMedicalProblem(selectedMedicalProblem);
                selectedVisit.addTreatment(selectedTreatment);
                JOptionPane.showMessageDialog(this, "Medical Problem and Treatment added successfully to the visit!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a visit, medical problem, and treatment.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000);
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        AddMedProWTtoVISIT frame = new AddMedProWTtoVISIT();
        frame.setVisible(true);
    }
}
