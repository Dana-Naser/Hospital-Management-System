package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import control.Hospital;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class getnumofdocbyspecial extends JFrame implements Serializable{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public getnumofdocbyspecial() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 993, 675);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        
     // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/pic/LOgoEnd.png")); // Ensure correct path
        Image logoImage = logoIcon.getImage().getScaledInstance(175, 70, Image.SCALE_SMOOTH); // Scale image
        logoLabel.setIcon(new ImageIcon(logoImage));
        logoLabel.setBounds(10, 10, 175, 70);
        contentPane.add(logoLabel);

        JLabel lblNewLabel = new JLabel("Number Of Doctors By Specialization");
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setBounds(225, 10, 544, 42);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 35));
        contentPane.add(lblNewLabel);

        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.menu);
        btnMain.setForeground(Color.WHITE);
        btnMain.setBounds(852, 13, 96, 42);
        btnMain.setFocusPainted(false);
        btnMain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnMain);

        JTextArea resultArea = new JTextArea();
        resultArea.setBackground(SystemColor.activeCaption);
        resultArea.setForeground(SystemColor.inactiveCaptionBorder);
        resultArea.setBounds(85, 93, 811, 471);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
        resultArea.setEditable(false);
        contentPane.add(resultArea);

        // Populate specialization counts
        displaySpecializationCounts(resultArea);
    }

    private void displaySpecializationCounts(JTextArea resultArea) {
        HashMap<enums.Specialization, Integer> specializationCounts = Hospital.getInstance().getNumberOfDoctorsBySpecialization();
        
        StringBuilder resultText = new StringBuilder("Specialization: Number of Doctors\n\n");
        
        for (enums.Specialization specialization : specializationCounts.keySet()) {
            resultText.append(String.format("%-30s: %d%n", specialization.toString(), specializationCounts.get(specialization)));
        }
        
        resultArea.setText(resultText.toString());
    }
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
