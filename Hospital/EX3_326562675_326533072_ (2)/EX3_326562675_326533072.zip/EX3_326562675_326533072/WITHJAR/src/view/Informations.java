package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.awt.event.ActionEvent;
import control.Hospital;
import java.awt.SystemColor;

public class Informations extends JFrame implements Serializable {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public Informations() {
		setFocusable(true);
		setTitle("informations");
		setBounds(100, 100, 1014, 735);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		  JLabel logoLabel = new JLabel();
	        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
	        Image image = icon.getImage();
	        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
	        ImageIcon scaledIcon = new ImageIcon(scaledImage);

	        JLabel lblNewLabel_1 = new JLabel();
	        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
	        lblNewLabel_1.setBounds(-14, 0, 277, 93); // Adjust the bounds as needed
	        contentPane.add(lblNewLabel_1);
	        
		  // Add "Main" button
        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.menu);
        btnMain.setForeground(Color.WHITE);
        btnMain.setBounds(824, 18, 102, 32);
        btnMain.setFocusPainted(false);
        btnMain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnMain);
    
		JLabel lblNewLabel = new JLabel("Hospital Information");
		lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel.setBounds(328, 11, 400, 47);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 40));
		contentPane.add(lblNewLabel);

	

		JTextArea resultArea = new JTextArea();
		resultArea.setForeground(SystemColor.inactiveCaptionBorder);
		resultArea.setBackground(SystemColor.activeCaption);
		resultArea.setBounds(50, 100, 900, 500);
		resultArea.setFont(new Font("Monospaced", Font.PLAIN, 30));
		resultArea.setEditable(false);
		contentPane.add(resultArea);

		// Display hospital information
		displayHospitalInfo(resultArea);
	}

	private void displayHospitalInfo(JTextArea resultArea) {
		// Retrieve the information from Hospital
		Hospital hospital = Hospital.getInstance();
		int intensiveCareStaffCount = hospital.howManyIntensiveCareStaffMembers();
		double averageSalary = hospital.avgSalary();
		boolean compliesWithStandard = hospital.isCompliesWithTheMinistryOfHealthStandard();

		// Build the result text
		StringBuilder resultText = new StringBuilder();
		
		resultText.append("Number of Intensive Care Staff Members: ").append(intensiveCareStaffCount).append("\n");
		resultText.append("Average Salary of Staff Members: $").append(String.format("%.2f", averageSalary)).append("\n");
		resultText.append("Complies with Ministry of Health Standard: ").append(compliesWithStandard ? "Yes" : "No").append("\n");

		// Display the result
		resultArea.setText(resultText.toString());
	}
	   // Play a sound effect
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
	
}
