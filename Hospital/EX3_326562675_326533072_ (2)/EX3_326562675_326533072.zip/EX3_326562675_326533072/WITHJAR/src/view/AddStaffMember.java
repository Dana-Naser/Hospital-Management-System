package view;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import control.Hospital;
import enums.Specialization;
import model.Doctor;
import model.IntensiveCareDoctor;
import model.IntensiveCareNurse;
import model.Nurse;
import java.awt.SystemColor;

public class AddStaffMember extends JFrame implements Serializable
{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField idtxt;
    private JTextField fntxt;
    private JTextField lntxt;
    private JTextField addresstxt;
    private JTextField phonetxt;
    private JTextField emailtxt;
    private JTextField gendertxt;
    private JTextField salarttxt;
    private JTextField licensetxt;
    private JComboBox<Specialization> specialization;
    private JComboBox<String> isfinishintership;
    private static int i = 0;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    private transient JDateChooser bdtxt;
    private transient JDateChooser wsdtxt;

    public AddStaffMember() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1038, 637);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
     // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 289, 80); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);


		
		JLabel lblNewLabel = new JLabel("Add Staffmember");
		lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(339, 21, 289, 60);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_11 = new JLabel("ID:");
		lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_11.setBounds(39, 169, 28, 25);
		contentPane.add(lblNewLabel_11);
		
		idtxt = new JTextField();
		idtxt.setBounds(151, 169, 216, 34);
		contentPane.add(idtxt);
		idtxt.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("First Name:");
		lblNewLabel_2.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(39, 214, 120, 22);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Last Name:");
		lblNewLabel_2_1.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2_1.setBounds(39, 259, 120, 25);
		contentPane.add(lblNewLabel_2_1);
		
		fntxt = new JTextField();
		fntxt.setBounds(151, 259, 216, 34);
		contentPane.add(fntxt);
		fntxt.setColumns(10);
		
		lntxt = new JTextField();
		lntxt.setBounds(151, 214, 216, 34);
		contentPane.add(lntxt);
		lntxt.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Birthdate:");
		lblNewLabel_3.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(39, 306, 96, 25);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Address:");
		lblNewLabel_4.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(39, 356, 106, 25);
		contentPane.add(lblNewLabel_4);
		
		addresstxt = new JTextField();
		addresstxt.setBounds(161, 392, 204, 33);
		contentPane.add(addresstxt);
		addresstxt.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("phoneNumber:");
		lblNewLabel_5.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel_5.setBounds(39, 400, 155, 25);
		contentPane.add(lblNewLabel_5);
		
		phonetxt = new JTextField();
		phonetxt.setBounds(151, 348, 214, 33);
		contentPane.add(phonetxt);
		phonetxt.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("email:");
		lblNewLabel_6.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_6.setBounds(447, 125, 65, 25);
		contentPane.add(lblNewLabel_6);
		
		emailtxt = new JTextField();
		emailtxt.setBounds(644, 125, 214, 33);
		contentPane.add(emailtxt);
		emailtxt.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Gender:");
		lblNewLabel_7.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_7.setBounds(447, 215, 96, 21);
		contentPane.add(lblNewLabel_7);
		
		gendertxt = new JTextField();
		gendertxt.setBounds(644, 213, 214, 33);
		contentPane.add(gendertxt);
		gendertxt.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Work Start Date:");
		lblNewLabel_8.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_8.setBounds(447, 169, 169, 25);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Salary:");
		lblNewLabel_9.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_9.setBounds(447, 259, 77, 25);
		contentPane.add(lblNewLabel_9);
		
		salarttxt = new JTextField();
		salarttxt.setBounds(644, 251, 214, 33);
		contentPane.add(salarttxt);
		salarttxt.setColumns(10);
		bdtxt = new JDateChooser();
        bdtxt.setBounds(151, 304, 216, 34);
        contentPane.add(bdtxt);
		
		JLabel lblNewLabel_10 = new JLabel("License Number:");
		lblNewLabel_10.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_10.setBounds(447, 306, 182, 25);
		contentPane.add(lblNewLabel_10);
		
		licensetxt = new JTextField();
		licensetxt.setBounds(644, 297, 214, 34);
		contentPane.add(licensetxt);
		licensetxt.setColumns(10);

        wsdtxt = new JDateChooser();
        wsdtxt.setBounds(644, 169, 214, 25);
        contentPane.add(wsdtxt);

		JLabel lblNewLabel_111 = new JLabel("Select:");
		lblNewLabel_111.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_111.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_111.setBounds(39, 125, 77, 25);
		contentPane.add(lblNewLabel_111);
		JComboBox<String> nord = new JComboBox();
		nord.setBounds(151, 116, 216, 34);
		contentPane.add(nord);
		nord.addItem("Choose:");
		nord.addItem("Doctor");
		nord.addItem("Nurse");
		
nord.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(nord.getSelectedIndex()==0) {
					idtxt.setEnabled(false);
					fntxt.setEnabled(false);
					lntxt.setEnabled(false);
					bdtxt.setEnabled(false);
					phonetxt.setEnabled(false);
					addresstxt.setEnabled(false);
					emailtxt.setEnabled(false);
					gendertxt.setEnabled(false);
					wsdtxt.setEnabled(false);
					salarttxt.setEnabled(false);
					licensetxt.setEnabled(false);
					isfinishintership.setEnabled(false);
					specialization.setEnabled(false);
					
				}
				 String s= (String) nord.getSelectedItem();
				 if(s.equals("Doctor")) {
					 idtxt.setEnabled(true);
						fntxt.setEnabled(true);
						lntxt.setEnabled(true);
						bdtxt.setEnabled(true);
						phonetxt.setEnabled(true);
						addresstxt.setEnabled(true);
						emailtxt.setEnabled(true);
						gendertxt.setEnabled(true);
						wsdtxt.setEnabled(true);
						salarttxt.setEnabled(true);
						licensetxt.setEnabled(true);
						isfinishintership.setEnabled(true);
						specialization.setEnabled(true);
						
					 i=1;
				 }
				 if(s.equals("Intensive Care Doctor")) {
					 idtxt.setEnabled(true);
						fntxt.setEnabled(true);
						lntxt.setEnabled(true);
						bdtxt.setEnabled(true);
						phonetxt.setEnabled(true);
						addresstxt.setEnabled(true);
						emailtxt.setEnabled(true);
						gendertxt.setEnabled(true);
						wsdtxt.setEnabled(true);
						salarttxt.setEnabled(true);
						licensetxt.setEnabled(true);
						isfinishintership.setEnabled(true);
						specialization.setEnabled(true);
					 i=2;
			}
				 if(s.equals("Nurse")) {
					 idtxt.setEnabled(true);
						fntxt.setEnabled(true);
						lntxt.setEnabled(true);
						bdtxt.setEnabled(true);
						phonetxt.setEnabled(true);
						addresstxt.setEnabled(true);
						emailtxt.setEnabled(true);
						gendertxt.setEnabled(true);
						wsdtxt.setEnabled(true);
						salarttxt.setEnabled(true);
						licensetxt.setEnabled(true);
						isfinishintership.setEnabled(false);
						specialization.setEnabled(true);
					 i=3;
				 }
				 if(s.equals("Intensive Care Nurse")) {
					 idtxt.setEnabled(true);
						fntxt.setEnabled(true);
						lntxt.setEnabled(true);
						bdtxt.setEnabled(true);
						phonetxt.setEnabled(true);
						addresstxt.setEnabled(true);
						emailtxt.setEnabled(true);
						gendertxt.setEnabled(true);
						wsdtxt.setEnabled(true);
						salarttxt.setEnabled(true);
						licensetxt.setEnabled(true);
						isfinishintership.setEnabled(false);
						specialization.setEnabled(true);
					 i=4;
				 }
			}
		});
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.setBackground(SystemColor.inactiveCaption);
		btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        createstaffmember(); // Assuming this method adds the staff member

		        try {
		            // Ensure that all components are initialized properly
		            if (idtxt != null) idtxt.setEnabled(false);
		            if (fntxt != null) fntxt.setEnabled(false);
		            if (lntxt != null) lntxt.setEnabled(false);
		            if (bdtxt != null) bdtxt.setEnabled(false);
		            if (phonetxt != null) phonetxt.setEnabled(false);
		            if (addresstxt != null) addresstxt.setEnabled(false);
		            if (emailtxt != null) emailtxt.setEnabled(false);
		            if (gendertxt != null) gendertxt.setEnabled(false);
		            if (wsdtxt != null) wsdtxt.setEnabled(false);
		            if (salarttxt != null) salarttxt.setEnabled(false);
		            if (licensetxt != null) licensetxt.setEnabled(false);
		            if (isfinishintership != null) isfinishintership.setEnabled(false);
		            if (specialization != null) specialization.setEnabled(false);
		        } catch (Exception ex) {
		            ex.printStackTrace(); // Properly handle any exceptions
		        }
		    }
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(356, 450, 120, 33);
		contentPane.add(btnNewButton);
		

        // Button "Main"
        JButton GobacktoMain = new JButton("Main");
        GobacktoMain.setBackground(SystemColor.inactiveCaption);
        GobacktoMain.setForeground(SystemColor.inactiveCaptionBorder);
        GobacktoMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        GobacktoMain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        GobacktoMain.setBounds(830, 11, 90, 39);
        contentPane.add(GobacktoMain);
        isfinishintership = new JComboBox<>(new String[]{"Yes", "No"});
		 isfinishintership.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                // Handle event here
	                if (isfinishintership != null) {
	                    isfinishintership.setEnabled(true);
	                }
	            }
	        });
		isfinishintership.setBounds(644, 348, 214, 33);
		contentPane.add(isfinishintership);
		
		
		JLabel lblNewLabel_13 = new JLabel("specialization:");
		lblNewLabel_13.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_13.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_13.setBounds(447, 400, 143, 24);
		contentPane.add(lblNewLabel_13);
		
		
		specialization = new JComboBox<Specialization>();
		for(Specialization s: Specialization.values())
			specialization.addItem(s);
		specialization.setBounds(644, 397, 214, 34);
		contentPane.add(specialization);
		
		
		
		JLabel lblNewLabel_12 = new JLabel("Is finishintership?");
		lblNewLabel_12.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_12.setBounds(447, 351, 181, 34);
		contentPane.add(lblNewLabel_12);
	}
	
	private void createstaffmember() {
	    try {
	        if (i == 0) {
	            JOptionPane.showMessageDialog(null, "Select StaffMember Type", "Error", JOptionPane.INFORMATION_MESSAGE);
	            return;
	        }

	        if (i == 1) {
	            if (idtxt.getText().isEmpty() || fntxt.getText().isEmpty() || lntxt.getText().isEmpty() || 
	                bdtxt.getDate() == null || addresstxt.getText().isEmpty() || salarttxt.getText().isEmpty() ||
	                phonetxt.getText().isEmpty() || emailtxt.getText().isEmpty() || gendertxt.getText().isEmpty() ||
	                wsdtxt.getDate() == null || licensetxt.getText().isEmpty() || specialization.getSelectedIndex() == -1 ||
	                isfinishintership.getSelectedIndex() == -1) {

	                JOptionPane.showMessageDialog(this, "Please fill in all fields and make selections for all dropdowns.", "Input Error", JOptionPane.ERROR_MESSAGE);
	                return;
	            }

	            int id = Integer.parseInt(idtxt.getText());
	            String firstname = fntxt.getText();
	            String lastname = lntxt.getText();
	            Date birthdate = bdtxt.getDate(); 
	            String address = addresstxt.getText();
	            Date workstartdate = wsdtxt.getDate(); 
	            Date comparisonDate = DATE_FORMAT.parse("2024-04-30");
		        if (!birthdate.before(comparisonDate) || !workstartdate.before(comparisonDate)) {
		            JOptionPane.showMessageDialog(this, "Birthdate and Work Start Date must be before April 30, 2024.", "Input Error", JOptionPane.ERROR_MESSAGE);
		            return;
		        }
	            String idText = idtxt.getText().trim();
	            String salaryText = salarttxt.getText().trim();

	            if (idText.isEmpty() || !idText.matches("\\d+")) {
	                JOptionPane.showMessageDialog(this, "ID must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
	                return;
	            }

	            if (salaryText.isEmpty() || !salaryText.matches("\\d+(\\.\\d+)?")) {
	                JOptionPane.showMessageDialog(this, "Salary must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
	                return;
	            }

	            String phonenumber = phonetxt.getText();
	            String email = emailtxt.getText();
	            String gender = gendertxt.getText();
	            double salary = Double.parseDouble(salarttxt.getText());
	            int licensenumber = Integer.parseInt(licensetxt.getText());

	            Specialization s = (Specialization) specialization.getSelectedItem();
	            String isFinished = (String) isfinishintership.getSelectedItem();
	            boolean s2 = isFinished.equals("Yes");

	            Doctor d = new Doctor(id, firstname, lastname, birthdate, address, phonenumber, email, gender, workstartdate, salary, licensenumber, s2, s);
	            if (Hospital.getInstance().addDoctor(d)) {
	                JOptionPane.showMessageDialog(this, "Doctor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
	                clearFields();
	            } else {
	                JOptionPane.showMessageDialog(this, "Failed to add the Doctor", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	        if(i==2) {
	        	  if (idtxt.getText().isEmpty() || fntxt.getText().isEmpty() || lntxt.getText().isEmpty() || 
	  	                bdtxt.getDate() == null || addresstxt.getText().isEmpty() || salarttxt.getText().isEmpty() ||
	  	                phonetxt.getText().isEmpty() || emailtxt.getText().isEmpty() || gendertxt.getText().isEmpty() ||
	  	                wsdtxt.getDate() == null || licensetxt.getText().isEmpty() || specialization.getSelectedIndex() == -1 ||
	  	                isfinishintership.getSelectedIndex() == 0) {
	        		  JOptionPane.showMessageDialog(this, "Please fill in all fields and make selections for all dropdowns.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
	        	  }
	        	  int id = Integer.parseInt(idtxt.getText());
		            String firstname = fntxt.getText();
		            String lastname = lntxt.getText();
		            Date birthdate = bdtxt.getDate(); 
		            String address = addresstxt.getText();
		            Date workstartdate = wsdtxt.getDate(); 

		            Date comparisonDate = DATE_FORMAT.parse("2024-04-30");
		            if (!birthdate.before(comparisonDate) || !workstartdate.before(comparisonDate)) {
		                JOptionPane.showMessageDialog(this, "Birthdate and Work Start Date must be before April 30, 2024.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }
		            String idText = idtxt.getText().trim();
		            String salaryText = salarttxt.getText().trim();

		            if (idText.isEmpty() || !idText.matches("\\d+")) {
		                JOptionPane.showMessageDialog(this, "ID must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            if (salaryText.isEmpty() || !salaryText.matches("\\d+(\\.\\d+)?")) {
		                JOptionPane.showMessageDialog(this, "Salary must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            String phonenumber = phonetxt.getText();
		            String email = emailtxt.getText();
		            String gender = gendertxt.getText();
		            double salary = Double.parseDouble(salarttxt.getText());
		            int licensenumber = Integer.parseInt(licensetxt.getText());

		            Specialization s = (Specialization) specialization.getSelectedItem();
		            String isFinished = (String) isfinishintership.getSelectedItem();
		            boolean s2 = isFinished.equals("Yes");

		            IntensiveCareDoctor d2 = new IntensiveCareDoctor(id, firstname, lastname, birthdate, address, phonenumber, email, gender, 
                           workstartdate, salary, licensenumber, s2);
		            if (Hospital.getInstance().addIntensiveCareDoctor(d2)) {
		                JOptionPane.showMessageDialog(this, "Intensive Care Doctor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		                clearFields();
		            } else {
		                JOptionPane.showMessageDialog(this, "Failed to add the Intensive Care Doctor", "Error", JOptionPane.ERROR_MESSAGE);
		            }
		        }
	        if(i==3) {
	        	if (idtxt.getText().isEmpty() || fntxt.getText().isEmpty() || lntxt.getText().isEmpty() || 
	  	                bdtxt.getDate() == null|| addresstxt.getText().isEmpty() || salarttxt.getText().isEmpty() ||
	  	                phonetxt.getText().isEmpty() || emailtxt.getText().isEmpty() || gendertxt.getText().isEmpty() ||
	  	                wsdtxt.getDate() == null || licensetxt.getText().isEmpty() ) {
	        		  JOptionPane.showMessageDialog(this, "Please fill in all fields and make selections for all dropdowns.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
	        	  }
	        	  int id = Integer.parseInt(idtxt.getText());
		            String firstname = fntxt.getText();
		            String lastname = lntxt.getText();
		            Date birthdate = bdtxt.getDate(); 
		            String address = addresstxt.getText();
		            Date workstartdate = wsdtxt.getDate(); 

		            Date comparisonDate = DATE_FORMAT.parse("2024-04-30");
		            if (!birthdate.before(comparisonDate) || !workstartdate.before(comparisonDate)) {
		                JOptionPane.showMessageDialog(this, "Birthdate and Work Start Date must be before April 30, 2024.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }
		            String idText = idtxt.getText().trim();
		            String salaryText = salarttxt.getText().trim();

		            if (idText.isEmpty() || !idText.matches("\\d+")) {
		                JOptionPane.showMessageDialog(this, "ID must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            if (salaryText.isEmpty() || !salaryText.matches("\\d+(\\.\\d+)?")) {
		                JOptionPane.showMessageDialog(this, "Salary must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            String phonenumber = phonetxt.getText();
		            String email = emailtxt.getText();
		            String gender = gendertxt.getText();
		            double salary = Double.parseDouble(salarttxt.getText());
		            int licensenumber = Integer.parseInt(licensetxt.getText());


		           Nurse n = new Nurse(id, firstname, lastname, birthdate, address, phonenumber, email, gender, 
                           workstartdate, salary, licensenumber);
		            if (Hospital.getInstance().addNurse(n)) {
		                JOptionPane.showMessageDialog(this, "Nurse added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		                clearFields();
		            } else {
		                JOptionPane.showMessageDialog(this, "Failed to add the Nurse", "Error", JOptionPane.ERROR_MESSAGE);
		            }
	        	
	        }
	        if(i==4) {
	        	if (idtxt.getText().isEmpty() || fntxt.getText().isEmpty() || lntxt.getText().isEmpty() || 
	  	                bdtxt.getDate() == null || addresstxt.getText().isEmpty() || salarttxt.getText().isEmpty() ||
	  	                phonetxt.getText().isEmpty() || emailtxt.getText().isEmpty() || gendertxt.getText().isEmpty() ||
	  	                wsdtxt.getDate() == null || licensetxt.getText().isEmpty()) {
	        		  JOptionPane.showMessageDialog(this, "Please fill in all fields and make selections for all dropdowns.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
	        	  }
	        	  int id = Integer.parseInt(idtxt.getText());
		            String firstname = fntxt.getText();
		            String lastname = lntxt.getText();
		            Date birthdate = bdtxt.getDate();
		            String address = addresstxt.getText();
		            Date workstartdate =wsdtxt.getDate();

		            Date comparisonDate =  DATE_FORMAT.parse("2024-04-30");
			        if (!birthdate.before(comparisonDate) || !workstartdate.before(comparisonDate)) {
			            JOptionPane.showMessageDialog(this, "Birthdate and Work Start Date must be before April 30, 2024.", "Input Error", JOptionPane.ERROR_MESSAGE);
			            return;
			        }
		            String idText = idtxt.getText().trim();
		            String salaryText = salarttxt.getText().trim();

		            if (idText.isEmpty() || !idText.matches("\\d+")) {
		                JOptionPane.showMessageDialog(this, "ID must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            if (salaryText.isEmpty() || !salaryText.matches("\\d+(\\.\\d+)?")) {
		                JOptionPane.showMessageDialog(this, "Salary must be a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
		                return;
		            }

		            String phonenumber = phonetxt.getText();
		            String email = emailtxt.getText();
		            String gender = gendertxt.getText();
		            double salary = Double.parseDouble(salarttxt.getText());
		            int licensenumber = Integer.parseInt(licensetxt.getText());

		    
		            IntensiveCareNurse d2 = new IntensiveCareNurse(id, firstname, lastname, birthdate, address, phonenumber, email, gender, 
                           workstartdate, salary, licensenumber);
		            if (Hospital.getInstance().addIntensiveCareNurse(d2)) {
		                JOptionPane.showMessageDialog(this, "Intensive Care Nurse added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		                clearFields();
		            } else {
		                JOptionPane.showMessageDialog(this, "Failed to add the Intensive Care Nurse", "Error", JOptionPane.ERROR_MESSAGE);
		            }
	        }
	        	  
	        i=0;
	    } catch (NumberFormatException ex) {
	        JOptionPane.showMessageDialog(this, "Invalid ID or Salary or licence Number format.", "Input Error", JOptionPane.ERROR_MESSAGE);
	    } catch (ParseException ex) {
	        JOptionPane.showMessageDialog(this, "Invalid birthdate or work start date format. Please use yyyy-MM-dd.", "Input Error", JOptionPane.ERROR_MESSAGE);
	    } catch (Exception ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(this, "An error occurred while adding the Doctor.", "Error", JOptionPane.ERROR_MESSAGE);
	    }
	    finally{
	    	clearFields();
	    	
	    }
	}


    private void clearFields() {
        idtxt.setText("");
        fntxt.setText("");
        lntxt.setText("");
        addresstxt.setText("");
        phonetxt.setText("");
        emailtxt.setText("");
        gendertxt.setText("");
        salarttxt.setText("");
        licensetxt.setText("");
        bdtxt.setDate(null); // Clear date field
        wsdtxt.setDate(null); // Clear date field
        isfinishintership.setSelectedIndex(0); // Reset combo box
        specialization.setSelectedIndex(0); // Reset combo box
    }
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000);
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AddStaffMember().setVisible(true);
        });
    }	
}