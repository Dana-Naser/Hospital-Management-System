package view;

import view.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import control.Hospital;
import model.*;

public class ShowMyData extends JFrame  implements Serializable {
    private JTextField idField;
    private JTextArea displayArea;
    private JButton searchButton, editButton, convertButton;
    private StaffMember staffMember;

    public ShowMyData() {
        setTitle("Show My Data");
        setSize(400, 300);
        getContentPane().setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        JLabel label = new JLabel("Enter ID Card Number:");
        label.setBackground(SystemColor.inactiveCaptionBorder);
        label.setForeground(SystemColor.activeCaption);
        inputPanel.add(label);
        idField = new JTextField();
        inputPanel.add(idField);

        searchButton = new JButton("Search");
        searchButton.setBackground(SystemColor.inactiveCaption);
        searchButton.setForeground(SystemColor.inactiveCaptionBorder);
        inputPanel.add(searchButton);

        editButton = new JButton("Edit");
        editButton.setBackground(SystemColor.inactiveCaption);
        editButton.setForeground(SystemColor.inactiveCaptionBorder);
        editButton.setEnabled(false);
        inputPanel.add(editButton);

        convertButton = new JButton("Convert to Intensive Care");
        convertButton.setBackground(SystemColor.inactiveCaption);
        convertButton.setForeground(SystemColor.inactiveCaptionBorder);
        convertButton.setEnabled(false);
        inputPanel.add(convertButton);

        getContentPane().add(inputPanel, BorderLayout.NORTH);

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        getContentPane().add(new JScrollPane(displayArea), BorderLayout.CENTER);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchStaffMember();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editStaffMemberDetails();
            }
        });

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertToIntensiveCare();
            }
        });
    }

    private void searchStaffMember() {
        String idText = idField.getText().trim();
        try {
            int id = Integer.parseInt(idText);
            staffMember = Hospital.getInstance().getStaffMember(id);

            if (staffMember != null) {
                displayStaffMemberDetails();
                editButton.setEnabled(true);
                // Enable the convert button only if the staff member is a Doctor or Nurse
                if (staffMember instanceof Doctor || staffMember instanceof Nurse) {
                    convertButton.setEnabled(true);
                } else {
                    convertButton.setEnabled(false);
                }
            } else {
                displayArea.setText("No staff member found with ID: " + id);
                editButton.setEnabled(false);
                convertButton.setEnabled(false);
            }
        } catch (NumberFormatException e) {
            displayArea.setText("Invalid ID. Please enter a numeric value.");
            editButton.setEnabled(false);
            convertButton.setEnabled(false);
        } catch (Exception e) {
            displayArea.setText("Error: " + e.getMessage());
            editButton.setEnabled(false);
            convertButton.setEnabled(false);
        }
    }

    private void displayStaffMemberDetails() {
        StringBuilder details = new StringBuilder();
        details.append("ID: ").append(staffMember.getId()).append("\n");
        details.append("Name: ").append(staffMember.getFirstName()).append(" ").append(staffMember.getLastName()).append("\n");
        details.append("Birth Date: ").append(staffMember.getBirthDate()).append("\n");
        details.append("Address: ").append(staffMember.getAddress()).append("\n");
        details.append("Phone Number: ").append(staffMember.getPhoneNumber()).append("\n");
        details.append("Email: ").append(staffMember.getEmail()).append("\n");
        details.append("Gender: ").append(staffMember.getGender()).append("\n");
        details.append("Work Start Date: ").append(staffMember.getWorkStartDate()).append("\n");
        details.append("Salary: ").append(staffMember.getSalary()).append("\n");

        displayArea.setText(details.toString());
    }

    private void editStaffMemberDetails() {
        String newAddress = JOptionPane.showInputDialog(this, "Enter new address:", staffMember.getAddress());
        String newPhoneNumber = JOptionPane.showInputDialog(this, "Enter new phone number:", staffMember.getPhoneNumber());
        String newEmail = JOptionPane.showInputDialog(this, "Enter new email:", staffMember.getEmail());

        if (newAddress != null && !newAddress.trim().isEmpty()) {
            staffMember.setAddress(newAddress);
        }
        if (newPhoneNumber != null && !newPhoneNumber.trim().isEmpty()) {
            staffMember.setPhoneNumber(newPhoneNumber);
        }
        if (newEmail != null && !newEmail.trim().isEmpty()) {
            staffMember.setEmail(newEmail);
        }

        displayStaffMemberDetails();
        JOptionPane.showMessageDialog(this, "Details updated successfully.");
    }

    private void convertToIntensiveCare() {
        if (staffMember instanceof Doctor) {
            Doctor intensiveCareDoctor = new IntensiveCareDoctor((Doctor) staffMember);
            Hospital.getInstance().updateStaffMember(intensiveCareDoctor);
            JOptionPane.showMessageDialog(this, "Doctor converted to Intensive Care Doctor.");
        } else if (staffMember instanceof Nurse) {
            Nurse intensiveCareNurse = new IntensiveCareNurse((Nurse) staffMember);
            Hospital.getInstance().updateStaffMember(intensiveCareNurse);
            JOptionPane.showMessageDialog(this, "Nurse converted to Intensive Care Nurse.");
        }
        displayStaffMemberDetails(); // Refresh the displayed details
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ShowMyData frame = new ShowMyData();
            frame.setVisible(true);
        });
    }
}
