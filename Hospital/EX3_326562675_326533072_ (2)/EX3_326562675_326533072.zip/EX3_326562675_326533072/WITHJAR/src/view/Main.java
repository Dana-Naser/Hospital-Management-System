//Dana Naser-326533072
//Layan Shawahny-326562675 

package view;

import control.Hospital;

import javax.swing.*;

import java.awt.EventQueue;
import java.io.IOException;
import java.io.Serializable;

public class Main implements Serializable{
    private static final String FILENAME = "Hospital.ser";

    public static void main(String[] args) {
        // Load the hospital data
        try {
            Hospital.loadHospital(FILENAME);
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error loading hospital data: " + e.getMessage(),
                    "Load Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        // Launch the login screen
        EventQueue.invokeLater(() -> {
            try {
            	login frame = new login();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Add a shutdown hook to save the hospital state when the application exits
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                Hospital.saveHospital(FILENAME);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }));
    }
}