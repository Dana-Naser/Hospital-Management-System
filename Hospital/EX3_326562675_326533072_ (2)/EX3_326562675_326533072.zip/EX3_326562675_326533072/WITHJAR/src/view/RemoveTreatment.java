package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.Hospital;
import model.Patient;
import model.Treatment;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class RemoveTreatment extends JFrame implements Serializable {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static int treatmentnum = 0;
	

	public RemoveTreatment() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 974, 534);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
	        Image image = icon.getImage();
	        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
	        ImageIcon scaledIcon = new ImageIcon(scaledImage);

	        JLabel lblNewLabel_1 = new JLabel();
	        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
	        lblNewLabel_1.setBounds(-21, 11, 303, 94); // Adjust the bounds as needed
	        contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Remove Treatment");
		lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel.setBounds(370, 50, 288, 42);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 35));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_11 = new JLabel("Which treatment are you removing?");
		lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblNewLabel_11.setBounds(296, 141, 493, 42);
		contentPane.add(lblNewLabel_11);
		
		JComboBox<Integer> comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				treatmentnum = (Integer) comboBox.getSelectedItem();
				
			}
		});
		comboBox.setBounds(352, 194, 295, 42);
		contentPane.add(comboBox);
		
		JButton Gotomain = new JButton("Main");
		Gotomain.setBackground(SystemColor.inactiveCaption);
		Gotomain.setForeground(SystemColor.inactiveCaptionBorder);
		Gotomain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin a = new Admin();
				a.setVisible(true);
				setVisible(false);
			}
		});
		Gotomain.setFont(new Font("Tahoma", Font.PLAIN, 20));
		Gotomain.setBounds(827, 29, 99, 41);
		contentPane.add(Gotomain);
		
		JButton btnNewButton = new JButton("Remove");
		btnNewButton.setBackground(SystemColor.inactiveCaption);
		btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				treatmentnum = (Integer) comboBox.getSelectedItem(); // Get selected Integer
				if ( Hospital.getInstance().removeTreatment(Hospital.getInstance().getRealTreatment(treatmentnum))) {
					JOptionPane.showMessageDialog(null, "Patient removed successfully.", 
							"Success", JOptionPane.INFORMATION_MESSAGE);
					comboBox.removeItem(treatmentnum); // Remove Integer from comboBox
					comboBox.setSelectedIndex(0);
				}
			
			}
		});
		for (Treatment t : Hospital.getInstance().getTreatments().values()) {
			if (t.getClass().equals(Treatment.class))
				comboBox.addItem(t.getSerialNumber());
		}
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnNewButton.setBounds(415, 251, 164, 42);
		contentPane.add(btnNewButton);
		
	}

}
