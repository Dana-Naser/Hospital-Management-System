package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Medication;
import java.io.IOException;
import java.io.Serializable;


public class AddMedication extends JFrame implements Serializable
 {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField codetxt;
    private JTextField nametxt;
    private JTextField dosagetxt;
    private JTextField numofdtxt;
    private Clip clip;
    private String userRole;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AddMedication frame = new AddMedication();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public AddMedication() {
        setTitle("Add Medication");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(0, 11, 278, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        // Title
        JLabel lblTitle = new JLabel("Add Medication", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 32));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(187, 41, 500, 40); // Adjusted bounds to account for logo space
        contentPane.add(lblTitle);

        // Code
        JLabel lblCode = new JLabel("Code:");
        lblCode.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblCode.setForeground(SystemColor.inactiveCaptionBorder);
        lblCode.setBounds(50, 120, 200, 30);
        contentPane.add(lblCode);

        codetxt = new JTextField();
        codetxt.setBounds(250, 120, 385, 30);
        contentPane.add(codetxt);

        // Name
        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblName.setForeground(SystemColor.inactiveCaptionBorder);
        lblName.setBounds(50, 160, 200, 30);
        contentPane.add(lblName);

        nametxt = new JTextField();
        nametxt.setBounds(250, 160, 385, 30);
        contentPane.add(nametxt);

        // Dosage
        JLabel lblDosage = new JLabel("Dosage:");
        lblDosage.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblDosage.setForeground(SystemColor.inactiveCaptionBorder);
        lblDosage.setBounds(50, 200, 200, 30);
        contentPane.add(lblDosage);

        dosagetxt = new JTextField();
        dosagetxt.setBounds(250, 200, 385, 30);
        contentPane.add(dosagetxt);

        // Number of Dose
        JLabel lblNumberOfDose = new JLabel("Number of Dose:");
        lblNumberOfDose.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblNumberOfDose.setForeground(SystemColor.inactiveCaptionBorder);
        lblNumberOfDose.setBounds(50, 240, 200, 30);
        contentPane.add(lblNumberOfDose);

        numofdtxt = new JTextField();
        numofdtxt.setBounds(250, 240, 385, 30);
        contentPane.add(numofdtxt);

        // Add Button
        JButton btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAdd.setBackground(SystemColor.text);
        btnAdd.setForeground(SystemColor.activeCaption);
        btnAdd.setBounds(250, 300, 100, 40);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                addMedication();
            }
        });
        contentPane.add(btnAdd);
        
        

     // Add back button
        JButton backButton = new JButton("Doctor Main");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
        backButton.setBackground(SystemColor.activeCaption);
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setBounds(10, 387, 124, 31);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new DoctorMainpage().setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(backButton);
        
        JButton btnNewButton = new JButton("ADMIN Main");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnNewButton.setBackground(SystemColor.activeCaption);
        btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
        btnNewButton.setBounds(159, 420, 139, 35);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 playSound("ss1.wav");
                 new Admin().setVisible(true);
                 setVisible(false);
        		
        	}
        });
        btnNewButton.setBounds(10, 420, 124, 33);
        contentPane.add(btnNewButton);
        setVisible(true); // Make sure the frame is visible
    


    }

    private void addMedication() {
        try {
            // Check if any field is empty
            if (codetxt.getText().isEmpty() || nametxt.getText().isEmpty() || dosagetxt.getText().isEmpty() || numofdtxt.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Parse input values
            int code = Integer.parseInt(codetxt.getText());
            String name = nametxt.getText();
            double dosage = Double.parseDouble(dosagetxt.getText());
            int numofdosage = Integer.parseInt(numofdtxt.getText());

            // Validate dosage number
            if (numofdosage <= 0) {
                JOptionPane.showMessageDialog(this, "The number of doses has to be greater than 0.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Create Medication object
            Medication m = new Medication(code, name, dosage, numofdosage);

            // Add medication to Hospital
            if (Hospital.getInstance().addMedication(m)) {
                JOptionPane.showMessageDialog(this, "Medication added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields(); // Clear input fields after successful addition
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add the medication.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for code, dosage, and number of doses.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to clear input fields
    private void clearFields() {
        codetxt.setText("");
        nametxt.setText("");
        dosagetxt.setText("");
        numofdtxt.setText("");
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
