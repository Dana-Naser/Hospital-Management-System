package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Disease;
import model.Fracture;
import model.Injury;
import model.MedicalProblem;
import java.io.Serializable;

public class RemoveMedicalProblem extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<String> medip;
    private JTextField nametxt;
    private JButton removeButton;

    public RemoveMedicalProblem() {
        setTitle("Remove Medical Problem");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500); // Adjust frame size to match the design
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title
        JLabel lblTitle = new JLabel("Remove Medical Problem", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 30));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(200, 20, 500, 40); // Adjusted bounds to account for logo space
        contentPane.add(lblTitle);

        // Name
        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblName.setForeground(SystemColor.inactiveCaptionBorder);
        lblName.setBounds(50, 120, 200, 30);
        contentPane.add(lblName);

        nametxt = new JTextField();
        nametxt.setBounds(250, 120, 385, 30);
        contentPane.add(nametxt);

        // Select Medical Problem
        JLabel lblSelectMedicalProblem = new JLabel("Select A Medical Problem:");
        lblSelectMedicalProblem.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblSelectMedicalProblem.setForeground(SystemColor.inactiveCaptionBorder);
        lblSelectMedicalProblem.setBounds(50, 79, 200, 30);
        contentPane.add(lblSelectMedicalProblem);

        medip = new JComboBox<>();
        medip.setBounds(250, 80, 385, 30);
        medip.addItem("Choose");
        medip.addItem("Injury");
        medip.addItem("Disease");
        medip.addItem("Fracture");
        contentPane.add(medip);

        // Remove Button
        removeButton = new JButton("Remove");
        removeButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        removeButton.setBackground(SystemColor.text);
        removeButton.setForeground(SystemColor.activeCaption);
        removeButton.setBounds(535, 416, 100, 40);
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removeMedicalProblem();
            }
        });
        contentPane.add(removeButton);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        backButton.setBackground(SystemColor.activeCaption);
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setBounds(149, 419, 139, 35);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new DoctorMainpage().setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(backButton);

        setVisible(true); // Make sure the frame is visible
    }

    private void removeMedicalProblem() {
        try {
            String selectedProblem = (String) medip.getSelectedItem();
            String name = nametxt.getText();

            if (selectedProblem.equals("Choose") || name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select a problem type and enter a name.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = false;

            // Depending on the selected problem type, cast the MedicalProblem object and remove it
            switch (selectedProblem) {
                case "Injury" -> {
                    Injury injury = (Injury) findMedicalProblemByName(name, Injury.class);
                    success = Hospital.getInstance().removeInjury(injury);
                }
                case "Disease" -> {
                    Disease disease = (Disease) findMedicalProblemByName(name, Disease.class);
                    success = Hospital.getInstance().removeDisease(disease);
                }
                case "Fracture" -> {
                    Fracture fracture = (Fracture) findMedicalProblemByName(name, Fracture.class);
                    success = Hospital.getInstance().removeFracture(fracture);
                }
            }

            if (success) {
                JOptionPane.showMessageDialog(this, selectedProblem + " removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "This " + selectedProblem + " does not exist in the system.", "Failure", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while removing the medical problem.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private MedicalProblem findMedicalProblemByName(String name, Class<? extends MedicalProblem> problemType) {
        // This method should search your medical problems collection and return
        // the appropriate MedicalProblem object based on its name and type.
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problemType.isInstance(problem) && problem.getName().equalsIgnoreCase(name)) {
                return problem;
            }
        }
        return null;
    }

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new RemoveMedicalProblem().setVisible(true);
        });
    }
}