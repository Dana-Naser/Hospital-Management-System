package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URISyntaxException;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import enums.BiologicalSex;
import enums.HealthFund;
import model.Patient;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddPatient extends JFrame implements Serializable
{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField Idtxt;
    private JTextField fntxt;
    private JTextField lntxt;
    private JTextField bdtxt;
    private JTextField adresstxt;
    private JTextField phonenumtxt;
    private JTextField emailtxt;
    private JComboBox<BiologicalSex> bio;
    private JComboBox<HealthFund> healthfund;
    private JTextField gendertxt;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private Clip clip;

    public AddPatient() {
        setTitle("Add Patient");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);


        // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 289, 80); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);


        // Title
        JLabel lblTitle = new JLabel("Add Patient", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 35));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(159, 10, 436, 51);
        contentPane.add(lblTitle);

        // ID
        JLabel lblID = new JLabel("ID:");
        lblID.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblID.setForeground(SystemColor.inactiveCaptionBorder);
        lblID.setBounds(50, 80, 100, 30);
        contentPane.add(lblID);

        Idtxt = new JTextField();
        Idtxt.setBounds(200, 80, 300, 30);
        contentPane.add(Idtxt);

        // First Name
        JLabel lblFirstName = new JLabel("First Name:");
        lblFirstName.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblFirstName.setForeground(SystemColor.inactiveCaptionBorder);
        lblFirstName.setBounds(50, 120, 120, 30);
        contentPane.add(lblFirstName);

        fntxt = new JTextField();
        fntxt.setBounds(200, 120, 300, 30);
        contentPane.add(fntxt);

        // Last Name
        JLabel lblLastName = new JLabel("Last Name:");
        lblLastName.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblLastName.setForeground(SystemColor.inactiveCaptionBorder);
        lblLastName.setBounds(50, 160, 100, 30);
        contentPane.add(lblLastName);

        lntxt = new JTextField();
        lntxt.setBounds(200, 160, 300, 30);
        contentPane.add(lntxt);

        // Birth Date
        JLabel lblBirthDate = new JLabel("BirthDate:");
        lblBirthDate.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblBirthDate.setForeground(SystemColor.inactiveCaptionBorder);
        lblBirthDate.setBounds(50, 200, 100, 30);
        contentPane.add(lblBirthDate);

        bdtxt = new JTextField();
        bdtxt.setBounds(200, 200, 300, 30);
        contentPane.add(bdtxt);

        // Address
        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblAddress.setForeground(SystemColor.inactiveCaptionBorder);
        lblAddress.setBounds(50, 240, 100, 30);
        contentPane.add(lblAddress);

        adresstxt = new JTextField();
        adresstxt.setBounds(200, 240, 300, 30);
        contentPane.add(adresstxt);

        // Phone Number
        JLabel lblPhoneNumber = new JLabel("Phone Number:");
        lblPhoneNumber.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblPhoneNumber.setForeground(SystemColor.inactiveCaptionBorder);
        lblPhoneNumber.setBounds(50, 280, 150, 30);
        contentPane.add(lblPhoneNumber);

        phonenumtxt = new JTextField();
        phonenumtxt.setBounds(200, 280, 300, 30);
        contentPane.add(phonenumtxt);

        // Email
        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblEmail.setForeground(SystemColor.inactiveCaptionBorder);
        lblEmail.setBounds(50, 320, 100, 30);
        contentPane.add(lblEmail);

        emailtxt = new JTextField();
        emailtxt.setBounds(200, 320, 300, 30);
        contentPane.add(emailtxt);

        // Biological Sex
        JLabel lblBiologicalSex = new JLabel("Biological Sex:");
        lblBiologicalSex.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblBiologicalSex.setForeground(SystemColor.inactiveCaptionBorder);
        lblBiologicalSex.setBounds(50, 360, 150, 30);
        contentPane.add(lblBiologicalSex);

        bio = new JComboBox<>();
        for (BiologicalSex b : BiologicalSex.values())
            bio.addItem(b);
        bio.setBounds(200, 360, 300, 30);
        contentPane.add(bio);

        // Health Fund
        JLabel lblHealthFund = new JLabel("Health Fund:");
        lblHealthFund.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblHealthFund.setForeground(SystemColor.inactiveCaptionBorder);
        lblHealthFund.setBounds(50, 400, 150, 30);
        contentPane.add(lblHealthFund);

        healthfund = new JComboBox<>();
        for (HealthFund h : HealthFund.values())
            healthfund.addItem(h);
        healthfund.setBounds(200, 400, 300, 30);
        contentPane.add(healthfund);

        // Gender
        JLabel lblGender = new JLabel("Gender(M/F):");
        lblGender.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblGender.setForeground(SystemColor.inactiveCaptionBorder);
        lblGender.setBounds(50, 440, 120, 30);
        contentPane.add(lblGender);

        gendertxt = new JTextField();
        gendertxt.setBounds(200, 440, 300, 30);
        contentPane.add(gendertxt);

        // Add Button
        JButton btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAdd.setBackground(SystemColor.text);
        btnAdd.setForeground(SystemColor.activeCaption);
        btnAdd.setBounds(415, 489, 120, 40);
        btnAdd.addActionListener(e -> {
            playSound("ss1.wav");
            Addpatient();
        });
        contentPane.add(btnAdd);

     // Add back button
        JButton backButton = new JButton("NURSE Main");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        backButton.setBackground(SystemColor.activeCaption);
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setBounds(594, 94, 169, 35);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new NurseMainpage().setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(backButton);
        
        JButton btnNewButton = new JButton("ADMIN Main");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton.setBackground(SystemColor.activeCaption);
        btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
        btnNewButton.setBounds(594, 135, 169, 35);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 playSound("ss1.wav");
                 new Admin().setVisible(true);
                 setVisible(false);
        		
        	}
        });
        
        contentPane.add(btnNewButton);
        setVisible(true); // Make sure the frame is visible
    
    }

    private void Addpatient() {
        try {
            if(Idtxt.getText().isEmpty() ||
               fntxt.getText().isEmpty() ||
               lntxt.getText().isEmpty() ||
               bdtxt.getText().isEmpty() ||
               adresstxt.getText().isEmpty() ||
               phonenumtxt.getText().isEmpty() ||
               emailtxt.getText().isEmpty() ||
               gendertxt.getText().isEmpty() ||
               bio.getSelectedIndex() == -1 ||
               healthfund.getSelectedIndex() == -1) {
        
                JOptionPane.showMessageDialog(this, "Please fill in all fields and make selections for all dropdowns.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int id = Integer.parseInt(Idtxt.getText());
            String firstname = fntxt.getText();
            String lastname = lntxt.getText();
            String phonenumber = phonenumtxt.getText();
            String address = adresstxt.getText();
            String email = emailtxt.getText();
            String gender = gendertxt.getText();
            BiologicalSex biol = (BiologicalSex) bio.getSelectedItem();
            HealthFund h = (HealthFund) healthfund.getSelectedItem();
            
            Date birthdate = DATE_FORMAT.parse(bdtxt.getText());
            Date comparisonDate = DATE_FORMAT.parse("2024-04-30");
            if (!birthdate.before(comparisonDate)) 
                JOptionPane.showMessageDialog(this, "Birthdate must be before April 30, 2024.", "Input Error", JOptionPane.ERROR_MESSAGE);
               
            

            Patient p = new Patient(id, firstname, lastname, birthdate, address, phonenumber, email, gender, h, biol);

            if (Hospital.getInstance().addPatient(p)) {
                JOptionPane.showMessageDialog(this, "Patient added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add the patient", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid IDnumber format.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Invalid birthdate format. Please use yyyy-MM-dd.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while adding the patient.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                new AddPatient();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    public void clearFields() {
        Idtxt.setText("");
        fntxt.setText("");
        lntxt.setText("");
        bdtxt.setText("");
        adresstxt.setText("");
        phonenumtxt.setText("");
        emailtxt.setText("");
        gendertxt.setText("");
        bio.setSelectedIndex(-1); // Assuming -1 represents no selection
        healthfund.setSelectedIndex(-1); // Assuming -1 represents no selection
    }
}
