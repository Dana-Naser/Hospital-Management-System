//Dana Naser-326533072
//Layan Shawahny-326562675
package view;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Admin extends JFrame implements Serializable
{

    private static final long serialVersionUID = 1L;
    private JPanel admin;
    private Hospital hospital = Hospital.getInstance();
    private Clip clip;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Admin frame = new Admin();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Admin() {
        setTitle("Admin Panel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1024, 768);
        admin = new JPanel();
        admin.setBackground(SystemColor.activeCaption);  // Set background color similar to AddDepartment
        admin.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(admin);
        admin.setLayout(null);

        // Add logo image
        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/pic/LOgoEnd.png")); // Ensure correct path
        Image logoImage = logoIcon.getImage().getScaledInstance(175, 70, Image.SCALE_SMOOTH); // Scale image
        logoLabel.setIcon(new ImageIcon(logoImage));
        logoLabel.setBounds(10, 11, 175, 70); // Adjust bounds as needed
        admin.add(logoLabel);

        // Title
        JLabel lblWelcome = new JLabel("hii Admin :)", JLabel.CENTER);
        lblWelcome.setFont(new Font("Times New Roman", Font.BOLD, 40));
        lblWelcome.setForeground(SystemColor.inactiveCaptionBorder);
        lblWelcome.setBounds(200, 25, 500, 60); // Adjusted to account for logo space
        admin.add(lblWelcome);

        JComboBox<String> addComboBox = new JComboBox<>();
        addComboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
        addComboBox.setBounds(326, 154, 250, 40);
        addComboBox.addItem("Add:");
        addComboBox.addItem("Add Visit");
        addComboBox.addItem("Add Department");
        addComboBox.addItem("Add Medical Problem");
        addComboBox.addItem("Add Staff Member");
        addComboBox.addItem("Add Medication");
        addComboBox.addItem("Add Patient");
        addComboBox.addItem("Add Treatment");
        addComboBox.addItem("Add Staff Member to Department");
        admin.add(addComboBox);

        addComboBox.addActionListener(e -> {
            playSound("ss1.wav");
            String selectedOption = (String) addComboBox.getSelectedItem();
            switch (selectedOption) {
                case "Add Visit":
                    new AddVisit().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Department":
                    new AddDepartment().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Medical Problem":
                    new AddMedicalProblem().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Staff Member":
                    new AddStaffMember().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Medication":
                    new AddMedication().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Patient":
                    new AddPatient().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Treatment":
                    new AddTreatment().setVisible(true);
                    setVisible(false);
                    break;
                case "Add Staff Member to Department":
                    new AddStaffMemberToDep(hospital).setVisible(true);
                    setVisible(false);
                    break;
            }
        });

        JComboBox<String> removeComboBox = new JComboBox<>();
        removeComboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
        removeComboBox.setBounds(326, 228, 256, 50);
        removeComboBox.addItem("Remove:");
        removeComboBox.addItem("Remove Visit");
        removeComboBox.addItem("Remove Department");
        removeComboBox.addItem("Remove Staff Member from Department");
        removeComboBox.addItem("Remove Medical Problem");
        removeComboBox.addItem("Remove Staff Member");
        removeComboBox.addItem("Remove Medication");
        removeComboBox.addItem("Remove Patient");
        removeComboBox.addItem("Remove Treatment");
        admin.add(removeComboBox);

        removeComboBox.addActionListener(e -> {
            playSound("ss1.wav");
            String selectedOption = (String) removeComboBox.getSelectedItem();
            switch (selectedOption) {
                case "Remove Visit":
                    new RemoveVisit().setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Department":
                    new removedep().setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Staff Member from Department":
                    new RemoveStaffMemberFromDep(hospital).setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Medical Problem":
                    new RemoveMedicalProblem().setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Staff Member":
                    new removestaff().setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Medication":
                    new RemoveMedication().setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Patient":
                    new RemovePatient().setVisible(true);
                    setVisible(false);
                    break;
                case "Remove Treatment":
                    new RemoveTreatment().setVisible(true);
                    setVisible(false);
                    break;
            }
        });

        // Modernized "View All Data" Button
        JButton viewDataBtn = new JButton("Show All Data");
        viewDataBtn.setFont(new Font("Tahoma", Font.BOLD, 20));
        viewDataBtn.setBounds(360, 380, 200, 50);
        viewDataBtn.setBackground(SystemColor.inactiveCaption);
        viewDataBtn.setForeground(Color.WHITE);
        viewDataBtn.setFocusPainted(false);
        viewDataBtn.setBorder(BorderFactory.createEmptyBorder());
        viewDataBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        viewDataBtn.addActionListener(e -> {
            playSound("ss1.wav");
            showAllData();
        });
        admin.add(viewDataBtn);

        JComboBox<String> methodsComboBox = new JComboBox<>();
        methodsComboBox.setFont(new Font("Tahoma", Font.PLAIN, 18));
        methodsComboBox.setBounds(326, 316, 256, 40);
        methodsComboBox.addItem("Methods");
        methodsComboBox.addItem("How many visits before");
        methodsComboBox.addItem("Count medications");
        methodsComboBox.addItem("Get number of doctors by specialization");
        methodsComboBox.addItem("Information");
        methodsComboBox.addItem("Appoint a new manager");
        admin.add(methodsComboBox);

        JLabel lblAddMethods = new JLabel("ADD METHODS");
        lblAddMethods.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblAddMethods.setForeground(SystemColor.inactiveCaptionBorder);
        lblAddMethods.setBounds(46, 154, 184, 40);
        admin.add(lblAddMethods);

        JLabel lblRemoveMethods = new JLabel("REMOVE METHODS");
        lblRemoveMethods.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblRemoveMethods.setForeground(SystemColor.inactiveCaptionBorder);
        lblRemoveMethods.setBounds(52, 250, 158, 28);
        admin.add(lblRemoveMethods);

        JLabel lblMore = new JLabel("MORE..");
        lblMore.setFont(new Font("Tahoma", Font.BOLD, 16));
        lblMore.setForeground(SystemColor.inactiveCaptionBorder);
        lblMore.setBounds(46, 321, 164, 37);
        admin.add(lblMore);

        methodsComboBox.addActionListener(e -> {
            playSound("ss1.wav");
            String selectedOption = (String) methodsComboBox.getSelectedItem();
            switch (selectedOption) {
                case "How many visits before":
                    new howmanyvisitsbefore().setVisible(true);
                    setVisible(false);
                    break;
                case "Count medications":
                    new countmedication().setVisible(true);
                    setVisible(false);
                    break;
                case "Get number of doctors by specialization":
                    new getnumofdocbyspecial().setVisible(true);
                    setVisible(false);
                    break;
                case "Information":
                    new Informations().setVisible(true);
                    setVisible(false);
                    break;
                case "Appoint a new manager":
                    new AppointNewManagerFrame().setVisible(true);
                    setVisible(false);
                    break;
            }
        });

        // Adding Logout button
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(SystemColor.text);
        logoutBtn.setForeground(SystemColor.activeCaption);
        logoutBtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        logoutBtn.setBounds(760, 30, 165, 51);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder());
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        // Single ActionListener for the logout button
        logoutBtn.addActionListener(e -> {
            playSound("ss1.wav"); // Play sound
            new login().setVisible(true); // Create and show the login window
            dispose(); // Close the current window
        });

        admin.add(logoutBtn); // Add the button to the content pane
        
        JButton btnNewButton = new JButton("DOCTOR PAGE");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		DoctorMainpage m = new DoctorMainpage();
        		m.setVisible(true);
        	}
        });
        btnNewButton.setBounds(69, 587, 141, 50);
        admin.add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("NURSE PAGE");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		NurseMainpage m = new NurseMainpage();
        		m.setVisible(true);
        		
        	}
        });
        btnNewButton_1.setBounds(234, 587, 128, 50);
        admin.add(btnNewButton_1);
    }

    private void showAllData() {
        StringBuilder data = new StringBuilder();

        // Option to search for a patient by ID
        String idInput = JOptionPane.showInputDialog(this, "Enter Patient ID to search (leave empty to show all):");
        boolean searchMode = idInput != null && !idInput.trim().isEmpty();
        Integer searchId = null;
        if (searchMode) {
            try {
                searchId = Integer.parseInt(idInput.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid ID format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        if (!searchMode) {
            data.append("\nDoctors:\n");
            for (StaffMember sm : Hospital.getInstance().getStaffMembers().values()) {
                if (sm instanceof Doctor) {
                    data.append(sm).append("\n");
                }
            }
            data.append("\nIntensive Care Doctors:\n");
            for (StaffMember sm2 : Hospital.getInstance().getStaffMembers().values()) {
                if (sm2 instanceof IntensiveCareDoctor) {
                    data.append(sm2).append("\n");
                }
            }

            data.append("\nNurses:\n");
            for (StaffMember sm : Hospital.getInstance().getStaffMembers().values()) {
                if (sm instanceof Nurse) {
                    data.append(sm).append("\n");
                }
            }
            data.append("\nIntensive Care Nurses:\n");
            for (StaffMember sm4 : Hospital.getInstance().getStaffMembers().values()) {
                if (sm4 instanceof IntensiveCareNurse) {
                    data.append(sm4).append("\n");
                }
            }
            
            data.append("\nDepartments:\n");
            for (Department department : Hospital.getInstance().getDepartments().values()) {
                data.append(department).append("\n");
            }

            data.append("\nPatients:\n");
            List<Patient> sortedPatients = new ArrayList<>(Hospital.getInstance().getPatients().values());
            Collections.sort(sortedPatients, Comparator.comparing(Patient::getId)); // Sorting by ID

            for (Patient patient : sortedPatients) {
                data.append(patient).append("\n");
            }

            data.append("\nVisits:\n");
            List<Visit> sortedVisits = new ArrayList<>(Hospital.getInstance().getVisits().values());
            Collections.sort(sortedVisits, Comparator.comparing(Visit::getNumber)); // Sorting visits by number

            for (Visit visit : sortedVisits) {
                data.append(visit).append("\n");
            }

            data.append("\nTreatments:\n");
            for (Treatment treatment : Hospital.getInstance().getTreatments().values()) {
                data.append(treatment).append("\n");
            }

            data.append("\nMedications:\n");
            for (Medication m : Hospital.getInstance().getMedications().values()) {
                data.append(m).append("\n");
            }

            // Separate Medical Problems by Type
            List<MedicalProblem> injuries = new ArrayList<>();
            List<MedicalProblem> diseases = new ArrayList<>();
            List<MedicalProblem> fractures = new ArrayList<>();
            
            for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
                if (problem instanceof Injury) {
                    injuries.add(problem);
                } else if (problem instanceof Disease) {
                    diseases.add(problem);
                } else if (problem instanceof Fracture) {
                    fractures.add(problem);
                }
            }

            // Sorting each list by name
            injuries.sort(Comparator.comparing(MedicalProblem::getName));
            diseases.sort(Comparator.comparing(MedicalProblem::getName));
            fractures.sort(Comparator.comparing(MedicalProblem::getName));

            data.append("\nInjuries:\n");
            for (MedicalProblem problem : injuries) {
                data.append(problem).append("\n");
            }

            data.append("\nDiseases:\n");
            for (MedicalProblem problem : diseases) {
                data.append(problem).append("\n");
            }

            data.append("\nFractures:\n");
            for (MedicalProblem problem : fractures) {
                data.append(problem).append("\n");
            }
        } else {
            Patient patient = Hospital.getInstance().getPatients().get(searchId);
            if (patient != null) {
                data.append("\nPatient Details:\n").append(patient).append("\n");
            } else {
                data.append("\nPatient with ID ").append(searchId).append(" not found.\n");
            }
        }

        JTextArea textArea = new JTextArea(data.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        JOptionPane.showMessageDialog(this, scrollPane, "View All Data", JOptionPane.INFORMATION_MESSAGE);
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000);
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}