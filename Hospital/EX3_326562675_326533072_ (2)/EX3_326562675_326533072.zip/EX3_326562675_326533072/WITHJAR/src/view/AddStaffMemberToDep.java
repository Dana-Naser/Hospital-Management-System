package view;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import control.Hospital;
import exceptions.ObjectAlreadyExistsException;
import exceptions.ObjectDoesNotExist;
import model.Doctor;
import model.Nurse;
import model.Department;

public class AddStaffMemberToDep extends JFrame implements Serializable {

    private JPanel contentPane;
    private JTextField staffIdField;
    private JTextField departmentIdField;
    private JComboBox<String> staffTypeComboBox;
    private Hospital hospital;

    public AddStaffMemberToDep(Hospital hospital) {
        this.hospital = hospital;

        setTitle("Add Staff Member to Department");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 713, 500);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-22, 0, 271, 76); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        JLabel lblStaffType = new JLabel("Staff Type:");
        lblStaffType.setForeground(SystemColor.inactiveCaptionBorder);
        lblStaffType.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblStaffType.setBounds(202, 126, 100, 25);
        contentPane.add(lblStaffType);

        staffTypeComboBox = new JComboBox<>(new String[]{"Doctor", "Nurse"});
        staffTypeComboBox.setBounds(335, 126, 200, 25);
        contentPane.add(staffTypeComboBox);

        JLabel lblStaffId = new JLabel("Staff ID:");
        lblStaffId.setForeground(SystemColor.inactiveCaptionBorder);
        lblStaffId.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblStaffId.setBounds(202, 173, 80, 25);
        contentPane.add(lblStaffId);

        staffIdField = new JTextField();
        staffIdField.setBounds(335, 173, 200, 25);
        contentPane.add(staffIdField);
        staffIdField.setColumns(10);

        JLabel lblDepartmentId = new JLabel("Department ID:");
        lblDepartmentId.setForeground(SystemColor.inactiveCaptionBorder);
        lblDepartmentId.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblDepartmentId.setBounds(202, 220, 123, 25);
        contentPane.add(lblDepartmentId);

        departmentIdField = new JTextField();
        departmentIdField.setBounds(335, 220, 200, 25);
        contentPane.add(departmentIdField);
        departmentIdField.setColumns(10);

        JButton addButton = new JButton("Add Staff Member to Department");
        addButton.setBackground(SystemColor.inactiveCaption);
        addButton.setForeground(SystemColor.inactiveCaptionBorder);
        addButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
        addButton.setBounds(216, 286, 264, 28);
        contentPane.add(addButton);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                addStaffMemberToDep();
            }
        });

        JButton backButton = new JButton("Main");
        backButton.setBackground(SystemColor.inactiveCaption);
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setBounds(570, 11, 107, 39);
        contentPane.add(backButton);
        
        JLabel lblNewLabel = new JLabel("Add Staff Member to Department");
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        lblNewLabel.setBounds(178, 71, 348, 28);
        contentPane.add(lblNewLabel);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new Admin().setVisible(true);
                setVisible(false);
            }
        });
    }

    private void addStaffMemberToDep() {
        try {
            int staffId = Integer.parseInt(staffIdField.getText());
            int departmentId = Integer.parseInt(departmentIdField.getText());
            String staffType = (String) staffTypeComboBox.getSelectedItem();

            Department department = hospital.getRealDepartment(departmentId);
            if (department == null) {
                throw new ObjectDoesNotExist(departmentId, "Department", null);
            }

            if (staffType.equals("Doctor")) {
                Doctor doctor = (Doctor) hospital.getStaffMember(staffId);
                if (doctor == null) {
                    throw new ObjectDoesNotExist(staffId, "Doctor", null);
                }
                department.addDoctor(doctor);
                JOptionPane.showMessageDialog(this, "Doctor added to department successfully!");
            } else if (staffType.equals("Nurse")) {
                Nurse nurse = (Nurse) hospital.getStaffMember(staffId);
                if (nurse == null) {
                    throw new ObjectDoesNotExist(staffId, "Nurse", null);
                }
                department.addNurse(nurse);
                JOptionPane.showMessageDialog(this, "Nurse added to department successfully!");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid IDs.");
        } catch (ObjectDoesNotExist ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (ObjectAlreadyExistsException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000);
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Hospital hospital = Hospital.getInstance(); // Use singleton instance of Hospital
        AddStaffMemberToDep frame = new AddStaffMemberToDep(hospital);
        frame.setVisible(true);
    }
}