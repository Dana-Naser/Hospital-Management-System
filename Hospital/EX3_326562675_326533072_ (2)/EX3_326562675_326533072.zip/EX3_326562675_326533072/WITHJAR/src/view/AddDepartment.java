package view;

import java.awt.*;
import java.io.File;
import java.io.IOException; // Import IOException
import java.io.Serializable;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import enums.Specialization;
import model.Department;
import model.Doctor;
import model.StaffMember;

public class AddDepartment extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField depnum;
    private JTextField depname;
    private JTextField location;
    private JComboBox<Doctor> doctorCombo;
    private JComboBox<Specialization> specializationCombo;
    private Clip clip;

    public AddDepartment() {
        setTitle("Add Department");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 450); // Adjust frame size as needed
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-12, 0, 257, 78); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        // Title
        JLabel lblTitle = new JLabel("Add Department", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 32));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(200, 20, 500, 40); // Adjusted bounds to account for logo space
        contentPane.add(lblTitle);

        // Department Number
        JLabel lblDepNum = new JLabel("Department Number:");
        lblDepNum.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblDepNum.setForeground(SystemColor.inactiveCaptionBorder);
        lblDepNum.setBounds(50, 80, 200, 30);
        contentPane.add(lblDepNum);

        depnum = new JTextField();
        depnum.setBounds(250, 80, 385, 30);
        contentPane.add(depnum);

        // Department Name
        JLabel lblDepName = new JLabel("Department Name:");
        lblDepName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblDepName.setForeground(SystemColor.inactiveCaptionBorder);
        lblDepName.setBounds(50, 120, 200, 30);
        contentPane.add(lblDepName);

        depname = new JTextField();
        depname.setBounds(250, 120, 385, 30);
        contentPane.add(depname);

        // Doctor Manager
        JLabel lblDoctor = new JLabel("Doctor Manager:");
        lblDoctor.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblDoctor.setForeground(SystemColor.inactiveCaptionBorder);
        lblDoctor.setBounds(50, 160, 200, 30);
        contentPane.add(lblDoctor);

        doctorCombo = new JComboBox<>();
        for (StaffMember staff : Hospital.getInstance().getStaffMembers().values()) {
            if (staff instanceof Doctor) {
                doctorCombo.addItem((Doctor) staff);
            }
        }
        doctorCombo.setBounds(250, 160, 385, 30);
        contentPane.add(doctorCombo);

        // Location
        JLabel lblLocation = new JLabel("Location:");
        lblLocation.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblLocation.setForeground(SystemColor.inactiveCaptionBorder);
        lblLocation.setBounds(50, 200, 200, 30);
        contentPane.add(lblLocation);

        location = new JTextField();
        location.setBounds(250, 200, 385, 30);
        contentPane.add(location);

        // Specialization
        JLabel lblSpecialization = new JLabel("Specialization:");
        lblSpecialization.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblSpecialization.setForeground(SystemColor.inactiveCaptionBorder);
        lblSpecialization.setBounds(50, 240, 200, 30);
        contentPane.add(lblSpecialization);

        specializationCombo = new JComboBox<>();
        for (Specialization s : Specialization.values()) {
            specializationCombo.addItem(s);
        }
        specializationCombo.setBounds(250, 240, 385, 30);
        contentPane.add(specializationCombo);

        JFrame frame = new JFrame();
        frame.setVisible(true);
        
        // Add Button
        JButton btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAdd.setBackground(SystemColor.text);
        btnAdd.setForeground(SystemColor.activeCaption);
        btnAdd.setBounds(250, 290, 100, 40);
        btnAdd.addActionListener(e -> {
            playSound("ss1.wav");
            createDepartment();
        });
        contentPane.add(btnAdd);

        // Back to Main Button
        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.activeCaption);
        btnMain.setForeground(SystemColor.inactiveCaptionBorder);
        btnMain.setBounds(661, 11, 100, 40);
        btnMain.addActionListener(e -> {
            playSound("ss1.wav");
            new Admin().setVisible(true);
            setVisible(false);
        });
        contentPane.add(btnMain);

        setVisible(true); // Make sure the frame is visible
    }

    private void clearFields() {
        depnum.setText("");
        depname.setText("");
        location.setText("");
        doctorCombo.setSelectedIndex(-1);
        specializationCombo.setSelectedIndex(-1);
    }

    private void createDepartment() {
        if (depnum.getText().isEmpty() || depname.getText().isEmpty() ||
            location.getText().isEmpty() || doctorCombo.getSelectedIndex() == -1 ||
            specializationCombo.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and make selections for all dropdowns.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int number = Integer.parseInt(depnum.getText());
            String name = depname.getText();
            String loc = location.getText();
            Doctor doctor = (Doctor) doctorCombo.getSelectedItem();
            Specialization specialization = (Specialization) specializationCombo.getSelectedItem();

            Department department = new Department(number, name, doctor, loc, specialization);
            if (Hospital.getInstance().addDepartment(department)) {
                JOptionPane.showMessageDialog(this, "Department added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add the Department", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Department Number format.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000);
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}