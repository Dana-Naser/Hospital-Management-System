package view;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.IntensiveCareDoctor;
import model.IntensiveCareNurse;
import model.Nurse;
import model.StaffMember;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JComboBox;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.SystemColor;

public class removestaff extends JFrame implements Serializable{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JCheckBox nurseCheckBox;
    private JCheckBox doctorCheckBox;
    private JButton removeButton;
    private JComboBox<Integer> staffMemberComboBox;
    private static int staffMemberId = 0;
    private JButton btnNewButton;

    /**
     * Create the frame.
     */
    public removestaff() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1014, 733);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
        


        // Title label
        JLabel titleLabel = new JLabel("Remove Staff Member");
        titleLabel.setForeground(SystemColor.inactiveCaptionBorder);
        titleLabel.setFont(new Font("Times New Roman", Font.PLAIN, 40));
        titleLabel.setBounds(347, 11, 372, 35);
        contentPane.add(titleLabel);

        // Instruction label
        JLabel selectTypeLabel = new JLabel("Select:");
        selectTypeLabel.setForeground(SystemColor.inactiveCaptionBorder);
        selectTypeLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        selectTypeLabel.setBounds(133, 129, 531, 35);
        contentPane.add(selectTypeLabel);

        // ComboBox to select staff members
        staffMemberComboBox = new JComboBox<>();
        staffMemberComboBox.setBounds(133, 267, 211, 28);
        contentPane.add(staffMemberComboBox);
        staffMemberComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (staffMemberComboBox.getSelectedIndex() != -1 && staffMemberComboBox.getSelectedItem() != null) {
                    staffMemberId = (Integer) staffMemberComboBox.getSelectedItem();
                    removeButton.setEnabled(true);
                }
            }
        });

        // Remove button
        removeButton = new JButton("Remove");
        removeButton.setBackground(SystemColor.inactiveCaption);
        removeButton.setForeground(SystemColor.inactiveCaptionBorder);
        removeButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
        removeButton.setBounds(133, 318, 158, 45);
        removeButton.setEnabled(false);  // Initially disabled
        contentPane.add(removeButton);
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                if (staffMemberId != 0) {
                    // ���� ����� ������ Hospital
                    Hospital.getInstance().getStaffMembers().remove(staffMemberId);
                    JOptionPane.showMessageDialog(null, "Staff member with ID " + staffMemberId + " removed.");
                    
                    // ���� ����� ��- JComboBox
                    staffMemberComboBox.removeItem(staffMemberId);
                    staffMemberComboBox.setSelectedIndex(0);

                    // ����� ���� ����� ������ ����� ����� ��� ����
                    staffMemberId = 0;
                    removeButton.setEnabled(false);
                }
            }
        });

        // Doctor checkbox
        doctorCheckBox = new JCheckBox("Doctor");
        doctorCheckBox.setForeground(SystemColor.inactiveCaptionBorder);
        doctorCheckBox.setBackground(SystemColor.activeCaption);
        doctorCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
        doctorCheckBox.setBounds(133, 181, 99, 23);
        contentPane.add(doctorCheckBox);
        doctorCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCheckboxSelection(doctorCheckBox, model.Doctor.class);
            }
        });

        // Nurse checkbox
        nurseCheckBox = new JCheckBox("Nurse");
        nurseCheckBox.setForeground(SystemColor.inactiveCaptionBorder);
        nurseCheckBox.setBackground(SystemColor.activeCaption);
        nurseCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
        nurseCheckBox.setBounds(133, 219, 99, 23);
        contentPane.add(nurseCheckBox);
        nurseCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCheckboxSelection(nurseCheckBox, Nurse.class);
            }
        });
        
        btnNewButton = new JButton("Main");
        btnNewButton.setBackground(SystemColor.inactiveCaption);
        btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		playSound("ss1.wav");
        		Admin a = new Admin();
        		a.setVisible(true);
        		setVisible(false);
        	}
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton.setBounds(814, 13, 111, 35);
        contentPane.add(btnNewButton);
    }

    /**
     * Handle the selection of a checkbox and populate the JComboBox with the appropriate staff members.
     */
    private void handleCheckboxSelection(JCheckBox selectedCheckBox, Class<? extends StaffMember> staffClass) {
        // Disable other checkboxes when one is selected
        disableOtherCheckboxes(selectedCheckBox);

        // Reset comboBox and populate it with the appropriate staff members
        staffMemberComboBox.removeAllItems();
        staffMemberComboBox.addItem(null); // Placeholder for "Choose"
        for (StaffMember s : Hospital.getInstance().getStaffMembers().values()) {
            if (staffClass.isInstance(s)) {
                staffMemberComboBox.addItem(s.getId());
            }
        }

        // Re-enable checkboxes if none are selected
        if (!selectedCheckBox.isSelected()) {
            enableAllCheckboxes();
            staffMemberComboBox.removeAllItems();
            removeButton.setEnabled(false);
        }
    }

    /**
     * Disable all other checkboxes except the selected one.
     */
    private void disableOtherCheckboxes(JCheckBox selectedCheckBox) {
        JCheckBox[] checkboxes = { doctorCheckBox, nurseCheckBox,  };
        for (JCheckBox checkBox : checkboxes) {
            if (checkBox != selectedCheckBox) {
                checkBox.setEnabled(false);
            }
        }
    }

    /**
     * Enable all checkboxes.
     */
    private void enableAllCheckboxes() {
        doctorCheckBox.setEnabled(true);
        nurseCheckBox.setEnabled(true);
   
    }
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
   
        
    
}
