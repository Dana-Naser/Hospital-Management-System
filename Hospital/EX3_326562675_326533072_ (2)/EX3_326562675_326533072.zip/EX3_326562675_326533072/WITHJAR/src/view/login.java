package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import control.Hospital;
import model.Doctor;
import model.Nurse;
import model.StaffMember;
import exceptions.NotCompletedException;

public class login extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField usernametextfield;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                login frame = new login();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public login() {
        setTitle("Hospital System Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(600, 600, 1000, 600);
        setLocationRelativeTo(null); // Center the frame
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Hospital System");
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 50));
        lblNewLabel.setBounds(323, 22, 397, 78);
        contentPane.add(lblNewLabel);

        JLabel username = new JLabel("Username:");
        username.setForeground(SystemColor.inactiveCaptionBorder);
        username.setFont(new Font("Times New Roman", Font.BOLD, 30));
        username.setBounds(323, 152, 178, 42);
        contentPane.add(username);

        JLabel lblNewLabel_1_1 = new JLabel("Password:");
        lblNewLabel_1_1.setBackground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_1_1.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 30));
        lblNewLabel_1_1.setBounds(323, 230, 171, 42);
        contentPane.add(lblNewLabel_1_1);

        usernametextfield = new JTextField();
        usernametextfield.setBounds(481, 165, 160, 28);
        contentPane.add(usernametextfield);
        usernametextfield.setColumns(10);

        passwordField = new JPasswordField();
        passwordField.setBounds(481, 243, 160, 28);
        contentPane.add(passwordField);

        showPasswordCheckBox = new JCheckBox("Show Password");
        showPasswordCheckBox.setBackground(SystemColor.activeCaption);
        showPasswordCheckBox.setForeground(SystemColor.inactiveCaptionBorder);
        showPasswordCheckBox.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        showPasswordCheckBox.setBounds(481, 278, 160, 28);
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
        });
        contentPane.add(showPasswordCheckBox);

        JButton btnLogIn = new JButton("Log In");
        btnLogIn.setBackground(SystemColor.text);
        btnLogIn.setForeground(SystemColor.activeCaption);
        btnLogIn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnLogIn.setBounds(323, 317, 165, 51);
        btnLogIn.addActionListener(e -> handleLogin());
        contentPane.add(btnLogIn);

        // Load and scale the image icon
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(0, 11, 289, 139); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
    }

    private void handleLogin() {
        try {
            String username = usernametextfield.getText();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty()) {
                throw new NotCompletedException("Failed to Login, Username is missing!");
            }
            if (password.isEmpty()) {
                throw new NotCompletedException("Failed to Login, Password is missing!");
            }

            if ("ADMIN".equals(username) && "ADMIN".equals(password)) {
                playSound("ss1.wav"); // Play success sound
                Admin adminPage = new Admin();
                adminPage.setVisible(true);
                dispose();
            } else {
                StaffMember staffMember = Hospital.getInstance().validateStaffMember(username, password);
                if (staffMember != null) {
                    Toolkit.getDefaultToolkit().beep();
                    if (staffMember instanceof Nurse) {
                        NurseMainpage nurseMainpage = new NurseMainpage();
                        nurseMainpage.setVisible(true);
                    } else if (staffMember instanceof Doctor) {
                        DoctorMainpage doctorMainpage = new DoctorMainpage();
                        doctorMainpage.setVisible(true);
                    }
                    dispose();
                } else {
                    playSound("error.wav"); // Play error sound
                    JOptionPane.showMessageDialog(contentPane, "Invalid username or password.");
                }
            }
        } catch (NotCompletedException ex) {
            playSound("error.wav"); // Play error sound for exceptions
            JOptionPane.showMessageDialog(this, "An error occurred: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            usernametextfield.setText("");
            passwordField.setText("");
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
            // Optionally wait for sound to finish
            Thread.sleep(clip.getMicrosecondLength() / 1000);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
