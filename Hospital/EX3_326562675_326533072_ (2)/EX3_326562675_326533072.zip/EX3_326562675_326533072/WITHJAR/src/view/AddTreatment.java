package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Treatment;
import javax.sound.sampled.*;

public class AddTreatment extends JFrame  implements Serializable
{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField serialnumber;
    private JTextArea des;
    private Clip clip;
    private String userRole;
    public AddTreatment() {
        setTitle("Add Treatment");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1033, 642);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);


        // Add logo image
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(0, 11, 278, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
        
        // Title
        JLabel lblTitle = new JLabel("Add Treatment", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 35));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(350, 29, 242, 65);
        contentPane.add(lblTitle);

        // Description Label
        JLabel lblDescription = new JLabel("Description:");
        lblDescription.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        lblDescription.setForeground(SystemColor.inactiveCaptionBorder);
        lblDescription.setBounds(286, 234, 137, 34);
        contentPane.add(lblDescription);

        // Serial Number Label
        JLabel lblSerialNumber = new JLabel("Serial Number:");
        lblSerialNumber.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        lblSerialNumber.setForeground(SystemColor.inactiveCaptionBorder);
        lblSerialNumber.setBounds(286, 167, 162, 34);
        contentPane.add(lblSerialNumber);

        // Serial Number TextField
        serialnumber = new JTextField();
        serialnumber.setBackground(SystemColor.window);
        serialnumber.setBounds(450, 162, 183, 39);
        contentPane.add(serialnumber);
        serialnumber.setColumns(10);

        // Description TextArea
        des = new JTextArea();
        des.setBackground(SystemColor.window);
        des.setWrapStyleWord(true);
        des.setLineWrap(true);
        des.setBounds(450, 234, 183, 98);
        contentPane.add(des);

        // Add Button
        JButton addButton = new JButton("Add");
        addButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
        addButton.setBackground(SystemColor.text);
        addButton.setForeground(SystemColor.activeCaption);
        addButton.setBounds(379, 362, 124, 49);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                addTreatment();
            }
        });
        contentPane.add(addButton);
        
        
        
     // Add back button
        JButton backButton1 = new JButton("Doctor Main");
        backButton1.setFont(new Font("Tahoma", Font.PLAIN, 15));
        backButton1.setBackground(SystemColor.activeCaption);
        backButton1.setForeground(SystemColor.inactiveCaptionBorder);
        backButton1.setBounds(10, 460, 124, 34);
        backButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new DoctorMainpage().setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(backButton1);
        
        JButton btnNewButton = new JButton("ADMIN Main");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnNewButton.setBackground(SystemColor.activeCaption);
        btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
        btnNewButton.setBounds(159, 420, 139, 35);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 playSound("ss1.wav");
                 new Admin().setVisible(true);
                 setVisible(false);
        		
        	}
        });
        btnNewButton.setBounds(10, 420, 124, 33);
        contentPane.add(btnNewButton);
        setVisible(true); // Make sure the frame is visible
    


    }

        

    private void clearFields() {
        serialnumber.setText("");
        des.setText("");
    }

    private void addTreatment() {
        if (serialnumber.getText().isEmpty() || des.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int number = Integer.parseInt(serialnumber.getText());
            String description = des.getText();
            Treatment treatment = new Treatment(number, description);

            if (Hospital.getInstance().addTreatment(treatment)) {
                JOptionPane.showMessageDialog(this, "Treatment added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add the Treatment", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Serial Number format.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                new AddTreatment().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
