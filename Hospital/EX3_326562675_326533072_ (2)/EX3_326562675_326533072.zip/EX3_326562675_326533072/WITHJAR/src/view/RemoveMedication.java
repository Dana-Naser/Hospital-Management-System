package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.Hospital;
import model.Medication;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.Serializable;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class RemoveMedication extends JFrame implements Serializable {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static Integer medicationcode = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RemoveMedication frame = new RemoveMedication();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RemoveMedication() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 941, 581);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		 ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
	        Image image = icon.getImage();
	        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
	        ImageIcon scaledIcon = new ImageIcon(scaledImage);

	        JLabel lblNewLabel_1 = new JLabel();
	        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
	        lblNewLabel_1.setBounds(-19, 11, 299, 95); // Adjust the bounds as needed
	        contentPane.add(lblNewLabel_1);
	        
		JLabel lblNewLabel = new JLabel("Remove Medication");
		lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel.setBounds(338, 151, 299, 42);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 35));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_11 = new JLabel("Which medication are you removing?");
		lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		lblNewLabel_11.setBounds(300, 204, 508, 42);
		contentPane.add(lblNewLabel_11);
		
		JComboBox<Integer> comboBox = new JComboBox();
		comboBox.setBounds(363, 259, 285, 42);
		contentPane.add(comboBox);
		
		JButton remove = new JButton("Remove");
		remove.setForeground(SystemColor.inactiveCaptionBorder);
		remove.setBackground(SystemColor.inactiveCaption);
		remove.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				medicationcode = (Integer) comboBox.getSelectedItem();
				if(medicationcode !=null && Hospital.getInstance().removeMedication(Hospital.getInstance().getRealMedication(medicationcode))) {
					JOptionPane.showMessageDialog(null, "medication removed successfully.", 
							"Success", JOptionPane.INFORMATION_MESSAGE);
					comboBox.removeItem(medicationcode); // Remove Integer from comboBox
					comboBox.setSelectedIndex(0);
				}
				
			}
		});
		for(Medication m: Hospital.getInstance().getMedications().values())
			if(m.getClass().equals(Medication.class))
				comboBox.addItem(m.getCode());
		
comboBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				medicationcode = (Integer) comboBox.getSelectedItem();
			}
		});
		
		remove.setFont(new Font("Tahoma", Font.PLAIN, 25));
		remove.setBounds(432, 371, 164, 54);
		contentPane.add(remove);
		
		JButton btnNewButton_1 = new JButton("Main");
		btnNewButton_1.setBackground(SystemColor.inactiveCaption);
		btnNewButton_1.setForeground(SystemColor.inactiveCaptionBorder);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin a = new Admin();
				a.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setBounds(756, 34, 95, 42);
		contentPane.add(btnNewButton_1);
	
	}

}
