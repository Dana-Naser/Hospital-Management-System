package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException; // Import IOException
import java.io.Serializable;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Medication;
import model.Treatment;

public class AddMedicationToTreatment extends JFrame implements Serializable
 {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JComboBox<Treatment> treatmentComboBox;
    private JComboBox<Medication> medicationComboBox;
    private Clip clip;

    public AddMedicationToTreatment() {
        setTitle("Add Medication to Treatment");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 891, 440); // Adjust frame size as needed
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption); // Set background color
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-35, 0, 280, 89); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        // Title
        JLabel lblTitle = new JLabel("Add Medication to Treatment", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 30));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder); // Title color
        lblTitle.setBounds(200, 20, 500, 40); // Adjusted bounds to account for logo space
        contentPane.add(lblTitle);

        // Select Treatment
        JLabel lblTreatment = new JLabel("Select Treatment:");
        lblTreatment.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblTreatment.setForeground(SystemColor.inactiveCaptionBorder); // Label color
        lblTreatment.setBounds(50, 100, 200, 30);
        contentPane.add(lblTreatment);

        treatmentComboBox = new JComboBox<>();
        treatmentComboBox.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        treatmentComboBox.setBounds(250, 100, 500, 30);
        contentPane.add(treatmentComboBox);
        loadTreatments();

        // Select Medication
        JLabel lblMedication = new JLabel("Select Medication:");
        lblMedication.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblMedication.setForeground(SystemColor.inactiveCaptionBorder); // Label color
        lblMedication.setBounds(50, 150, 200, 30);
        contentPane.add(lblMedication);

        medicationComboBox = new JComboBox<>();
        medicationComboBox.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        medicationComboBox.setBounds(250, 150, 500, 30);
        contentPane.add(medicationComboBox);
        loadMedications();

        // Add Medication Button
        JButton btnAddMedication = new JButton("Add Medication");
        btnAddMedication.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAddMedication.setBackground(SystemColor.text); // Button color
        btnAddMedication.setForeground(SystemColor.activeCaption); // Button text color
        btnAddMedication.setBounds(250, 200, 200, 40);
        btnAddMedication.addActionListener(e -> {
            playSound("ss1.wav"); // Play sound effect
            addMedicationToTreatment();
        });
        contentPane.add(btnAddMedication);

        // Main button to navigate back to the main page
        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.activeCaption);
        btnMain.setForeground(SystemColor.inactiveCaptionBorder);
        btnMain.setBounds(695, 18, 122, 40);
        btnMain.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                DoctorMainpage mainPage = new DoctorMainpage();
                mainPage.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnMain);
    }

    private void loadTreatments() {
        for (Treatment treatment : Hospital.getInstance().getTreatments().values()) {
            treatmentComboBox.addItem(treatment);
        }
    }

    private void loadMedications() {
        for (Medication medication : Hospital.getInstance().getMedications().values()) {
            medicationComboBox.addItem(medication);
        }
    }

    private void addMedicationToTreatment() {
        Treatment selectedTreatment = (Treatment) treatmentComboBox.getSelectedItem();
        Medication selectedMedication = (Medication) medicationComboBox.getSelectedItem();

        if (selectedTreatment != null && selectedMedication != null) {
            try {
                if (selectedTreatment.addMedication(selectedMedication)) {
                    JOptionPane.showMessageDialog(this, "Medication added successfully to the treatment!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Medication already exists in the treatment!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select both a treatment and a medication.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
