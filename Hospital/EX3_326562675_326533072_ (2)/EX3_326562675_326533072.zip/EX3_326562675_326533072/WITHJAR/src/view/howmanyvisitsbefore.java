package view;

import java.awt.Color;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Image;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import java.awt.SystemColor;

public class howmanyvisitsbefore extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private transient JPanel contentPane;
    private static final transient SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private JTextField howmany;
    private JDateChooser dateChooser; // Declare JDateChooser as a class member

    public howmanyvisitsbefore() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 879, 527);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel = new JLabel("How Many Visits Before");
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setBounds(278, 57, 356, 42);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 35));
        contentPane.add(lblNewLabel);

        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.menu);
        btnMain.setForeground(Color.WHITE);
        btnMain.setBounds(680, 29, 96, 33);
        btnMain.setFocusPainted(false);
        btnMain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnMain);

        JLabel lblNewLabel_2 = new JLabel("Date:");
        lblNewLabel_2.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblNewLabel_2.setBounds(307, 136, 102, 47);
        contentPane.add(lblNewLabel_2);

        howmany = new JTextField();
        howmany.setEditable(false); // Make it non-editable as it's for displaying results
        howmany.setBounds(383, 200, 183, 33);
        contentPane.add(howmany);
        howmany.setColumns(10);

        dateChooser = new JDateChooser(); // Initialize JDateChooser
        dateChooser.setBounds(383, 142, 183, 41);
        contentPane.add(dateChooser);

        JLabel lblNewLabel_11 = new JLabel("Result");
        lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_11.setBounds(307, 194, 102, 47);
        contentPane.add(lblNewLabel_11);

        JButton btnCalculate = new JButton("Calculate");
        btnCalculate.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnCalculate.setBackground(SystemColor.menu);
        btnCalculate.setForeground(Color.WHITE);
        btnCalculate.setBounds(366, 263, 163, 42);
        btnCalculate.setFocusPainted(false);
        btnCalculate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                calculateVisitsBefore();
            }
        });
        contentPane.add(btnCalculate);
    }

    private void calculateVisitsBefore() {
        Date selectedDate = dateChooser.getDate();
        if (selectedDate != null) {
            int count = Hospital.getInstance().howManyVisitBefore(selectedDate);
            howmany.setText(String.valueOf(count));
        } else {
            JOptionPane.showMessageDialog(this, "Please select a date.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}