package view;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.Hospital;

import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

public class countmedication extends JFrame implements Serializable{

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;

    public countmedication() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 901, 446);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(10, 11, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel = new JLabel("Count Medications");
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setBounds(332, 44, 319, 42);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 40));
        contentPane.add(lblNewLabel);
        
        JButton btnMain = new JButton("Main");
        btnMain.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnMain.setBackground(SystemColor.menu);
        btnMain.setForeground(Color.WHITE);
        btnMain.setBounds(702, 27, 109, 42);
        btnMain.setFocusPainted(false);
        btnMain.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav"); // Play sound effect
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnMain);

        textField = new JTextField();
        textField.setBounds(425, 114, 183, 33);
        contentPane.add(textField);
        textField.setColumns(10);
        
        JLabel lblNewLabel_11 = new JLabel("Count:");
        lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblNewLabel_11.setBounds(339, 114, 127, 42);
        contentPane.add(lblNewLabel_11);
        
        // Automatically update the medication count when the window is opened
        countmedication();
    }
    
    private void countmedication() {
        int count = Hospital.getInstance().getMedications().size();
        textField.setText(String.valueOf(count));
    }
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
