package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Department;
import model.Disease;
import model.Fracture;
import model.Injury;
import java.io.IOException;
import java.io.Serializable;

public class AddMedicalProblem extends JFrame implements Serializable
 {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField nametxt;
    private JTextField locationtxt;
    private JTextField crtxt;
    private JTextArea destxt;
    private JComboBox<String> medip;
    private JComboBox<Integer> departments;
    private JComboBox<String> requtxt;
    private int selectedProblemType = 0;
    private Clip clip;
    private String userRole;
    
    
    public AddMedicalProblem() {
        setTitle("Add Medical Problem");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500); // Adjust frame size to match the design
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(0, 0, 271, 76); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        // Title
        JLabel lblTitle = new JLabel("Add Medical Problem", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 30));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(200, 20, 500, 40); // Adjusted bounds to account for logo space
        contentPane.add(lblTitle);

        // Name
        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblName.setForeground(SystemColor.inactiveCaptionBorder);
        lblName.setBounds(50, 120, 200, 30);
        contentPane.add(lblName);

        nametxt = new JTextField();
        nametxt.setBounds(250, 120, 385, 30);
        contentPane.add(nametxt);

        // Description
        JLabel lblDescription = new JLabel("Description:");
        lblDescription.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblDescription.setForeground(SystemColor.inactiveCaptionBorder);
        lblDescription.setBounds(50, 202, 200, 30);
        contentPane.add(lblDescription);

        destxt = new JTextArea();
        destxt.setBounds(250, 160, 385, 70);
        destxt.setLineWrap(true);
        destxt.setWrapStyleWord(true);
        contentPane.add(destxt);

        // Select Medical Problem
        JLabel lblSelectMedicalProblem = new JLabel("Select A Medical Problem:");
        lblSelectMedicalProblem.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblSelectMedicalProblem.setForeground(SystemColor.inactiveCaptionBorder);
        lblSelectMedicalProblem.setBounds(50, 79, 200, 30);
        contentPane.add(lblSelectMedicalProblem);

        medip = new JComboBox<>();
        medip.setBounds(250, 80, 385, 30);
        medip.addItem("Choose");
        medip.addItem("Injury");
        medip.addItem("Disease");
        medip.addItem("Fracture");
        contentPane.add(medip);
        medip.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleMedicalProblemSelection();
            }
        });

        // Department
        JLabel lblDepartment = new JLabel("Department:");
        lblDepartment.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblDepartment.setForeground(SystemColor.inactiveCaptionBorder);
        lblDepartment.setBounds(50, 243, 200, 30);
        contentPane.add(lblDepartment);

        departments = new JComboBox<>();
        departments.setBounds(250, 245, 385, 30);
        for (Department d : Hospital.getInstance().getDepartments().values()) {
            departments.addItem(d.getNumber());
        }
        contentPane.add(departments);

        // Location
        JLabel lblLocation = new JLabel("Location:");
        lblLocation.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblLocation.setForeground(SystemColor.inactiveCaptionBorder);
        lblLocation.setBounds(50, 284, 200, 30);
        contentPane.add(lblLocation);

        locationtxt = new JTextField();
        locationtxt.setBounds(250, 284, 385, 30);
        contentPane.add(locationtxt);

        // Common Recovery
        JLabel lblCommonRecovery = new JLabel("Common Recovery:");
        lblCommonRecovery.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblCommonRecovery.setForeground(SystemColor.inactiveCaptionBorder);
        lblCommonRecovery.setBounds(50, 325, 200, 30);
        contentPane.add(lblCommonRecovery);

        crtxt = new JTextField();
        crtxt.setBounds(250, 325, 385, 30);
        contentPane.add(crtxt);

        // Requires Cast
        JLabel lblRequiresCast = new JLabel("Requires Cast?");
        lblRequiresCast.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblRequiresCast.setForeground(SystemColor.inactiveCaptionBorder);
        lblRequiresCast.setBounds(50, 366, 200, 30);
        contentPane.add(lblRequiresCast);

        requtxt = new JComboBox<>(new String[]{"Yes", "No"});
        requtxt.setBounds(250, 368, 385, 30);
        contentPane.add(requtxt);
        
          // Add Button
        JButton btnAdd = new JButton("Add");
        btnAdd.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnAdd.setBackground(SystemColor.text);
        btnAdd.setForeground(SystemColor.activeCaption);
        btnAdd.setBounds(535, 416, 100, 40);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                createMedicalProblem();
            }
        });
        contentPane.add(btnAdd);
     // Add back button
        JButton backButton = new JButton("Doctor Main");
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
        backButton.setBackground(SystemColor.activeCaption);
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setBounds(144, 423, 124, 30);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new DoctorMainpage().setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(backButton);
        
        JButton btnNewButton = new JButton("ADMIN Main");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnNewButton.setBackground(SystemColor.activeCaption);
        btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
        btnNewButton.setBounds(10, 423, 124, 30);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 playSound("ss1.wav");
                 new Admin().setVisible(true);
                 setVisible(false);
        		
        	}
        });
        btnNewButton.setBounds(10, 420, 124, 33);
        contentPane.add(btnNewButton);
        setVisible(true); // Make sure the frame is visible
    


    }


    private void handleMedicalProblemSelection() {
        String selected = (String) medip.getSelectedItem();
        selectedProblemType = switch (selected) {
            case "Injury" -> 1;
            case "Disease" -> 2;
            case "Fracture" -> 3;
            default -> 0;
        };
        updateFieldStates();
    }



    private void updateFieldStates() {
        boolean enableLocation = selectedProblemType == 1 || selectedProblemType == 3;
        boolean enableDescription = selectedProblemType == 2;
        boolean enableRecovery = selectedProblemType == 1;
        boolean enableCast = selectedProblemType == 3;

        nametxt.setEnabled(selectedProblemType != 0);
        departments.setEnabled(selectedProblemType != 0);
        locationtxt.setEnabled(enableLocation);
        destxt.setEnabled(enableDescription);
        crtxt.setEnabled(enableRecovery);
        requtxt.setEnabled(enableCast);
    }

    private void createMedicalProblem() {
        try {
            if (selectedProblemType == 0) {
                JOptionPane.showMessageDialog(this, "Select Medical Problem Type", "Error", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            switch (selectedProblemType) {
                case 1 -> createInjury();
                case 2 -> createDisease();
                case 3 -> createFracture();
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid number format. Please check your input.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while adding the medical problem.", "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            clearFields();
            updateFieldStates();
        }
    }

    private void createInjury() {
        if (isFieldEmpty(nametxt, locationtxt, crtxt) || departments.getSelectedIndex() == -1) {
            showError("Please fill in all fields and make selections for all dropdowns.");
            return;
        }

        String name = nametxt.getText();
        String location = locationtxt.getText();
        double commonRecovery = Double.parseDouble(crtxt.getText());
        Department department = getSelectedDepartment();

        Injury injury = new Injury(name, department, commonRecovery, location);
        handleResult(Hospital.getInstance().addInjury(injury), "Injury");
    }

    private void createDisease() {
        if (isFieldEmpty(nametxt, destxt) || departments.getSelectedIndex() == -1) {
            showError("Please fill in all fields and make selections for all dropdowns.");
            return;
        }

        String name = nametxt.getText();
        Department department = getSelectedDepartment();
        String description = destxt.getText();

        Disease disease = new Disease(name, department, description);
        handleResult(Hospital.getInstance().addDisease(disease), "Disease");
    }

    private boolean isFieldEmpty(JTextField nametxt2, JTextArea destxt2) {
		// TODO Auto-generated method stub
		return false;
	}

	private void createFracture() {
        if (isFieldEmpty(nametxt, locationtxt) || departments.getSelectedIndex() == -1 || requtxt.getSelectedIndex() == -1) {
            showError("Please fill in all fields and make selections for all dropdowns.");
            return;
        }

        String name = nametxt.getText();
        String location = locationtxt.getText();
        boolean requiresCast = requtxt.getSelectedItem().equals("Yes");
        Department department = getSelectedDepartment();

        Fracture fracture = new Fracture(name, department, location, requiresCast);
        handleResult(Hospital.getInstance().addFracture(fracture), "Fracture");
    }

    private void handleResult(boolean success, String problemType) {
        if (success) {
            JOptionPane.showMessageDialog(this, problemType + " added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "This " + problemType + " already exists in the system.", "Failure", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        nametxt.setText("");
        locationtxt.setText("");
        crtxt.setText("");
        destxt.setText("");
        requtxt.setSelectedIndex(-1);
    }

    private Department getSelectedDepartment() {
        return Hospital.getInstance().getDepartments().get(departments.getSelectedItem());
    }

    private boolean isFieldEmpty(JTextField... fields) {
        for (JTextField field : fields) {
            if (field.getText().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AddMedicalProblem().setVisible(true);
        });
    }
}
