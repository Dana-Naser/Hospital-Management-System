package view;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import control.Hospital;
import model.Department;
import model.Doctor;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class AppointNewManagerFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public AppointNewManagerFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 993, 569);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		// Add logo image
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(0, 11, 278, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel = new JLabel("Appoint A New Manager");
		lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel.setBounds(318, 102, 361, 42);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 35));
		contentPane.add(lblNewLabel);

		JLabel lblDepartment = new JLabel("Select Department:");
		lblDepartment.setForeground(SystemColor.inactiveCaptionBorder);
		lblDepartment.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDepartment.setBounds(318, 175, 200, 30);
		contentPane.add(lblDepartment);

		JComboBox<Department> departmentComboBox = new JComboBox<>();
		departmentComboBox.setBounds(507, 179, 250, 30);
		contentPane.add(departmentComboBox);

		JTextArea resultArea = new JTextArea();
		resultArea.setBounds(284, 226, 494, 173);
		resultArea.setFont(new Font("Monospaced", Font.PLAIN, 20));
		resultArea.setEditable(false);
		contentPane.add(resultArea);

		// Load departments into the JComboBox
		for (Department department : Hospital.getInstance().getDepartments().values()) {
			departmentComboBox.addItem(department);
		}

		// Automatically appoint a new manager when a department is selected
		departmentComboBox.addActionListener(e -> {
			Department selectedDepartment = (Department) departmentComboBox.getSelectedItem();
			if (selectedDepartment != null) {
				Doctor newManager = Hospital.getInstance().AppointANewManager(selectedDepartment);
				displayManagerAppointment(resultArea, selectedDepartment, newManager);
			}
		});
		
		// Add "Main" button outside the ActionListener
		JButton btnNewButton = new JButton("Main");
		btnNewButton.setBackground(SystemColor.inactiveCaption);
		btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Admin a = new Admin();
				a.setVisible(true);
				setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(862, 18, 94, 33);
		contentPane.add(btnNewButton);
	}

	// Display the result of manager appointment
	private void displayManagerAppointment(JTextArea resultArea, Department department, Doctor newManager) {
		if (newManager != null) {
			resultArea.setText("New manager appointed to department: " + department.getName() + "\n");
			resultArea.append("Doctor " + newManager.getFirstName() + " " + newManager.getLastName() + " has been appointed as the new manager.\n");
			resultArea.append("Their new salary is: $" + newManager.getSalary() + "\n");
		} else {
			resultArea.setText("No eligible doctor found for appointment in department: " + department.getName() + "\n");
		}
	}
	
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AppointNewManagerFrame().setVisible(true);
        });
    }
}
