package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.SystemColor;

public class Logout extends JButton implements Serializable {

    public Logout(JFrame currentFrame) {
        super("Logout");
        setBounds(850, 20, 120, 40); // Set position and size of the logout button
        setFont(new Font("Tahoma", Font.PLAIN, 20));
        setBackground(SystemColor.inactiveCaption);
        setForeground(SystemColor.inactiveCaptionBorder);

        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Close the current frame and return to the login screen
                currentFrame.setVisible(false);
                new login().setVisible(true);
            }
        });
    }
}
