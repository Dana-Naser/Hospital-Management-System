package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import control.Hospital;
import model.Visit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JComboBox;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class RemoveVisit extends JFrame  implements Serializable {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private static Integer visitnumber = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RemoveVisit frame = new RemoveVisit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RemoveVisit() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1011, 638);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Remove Visit");
		lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel.setBounds(357, 14, 229, 55);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 35));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Select one :");
		lblNewLabel_1.setForeground(SystemColor.inactiveCaptionBorder);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(285, 110, 153, 42);
		contentPane.add(lblNewLabel_1);
		
		JComboBox<Integer> comboBox = new JComboBox<>();
		comboBox.setBounds(448, 110, 209, 35);
		contentPane.add(comboBox);

		 
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_11 = new JLabel();
        lblNewLabel_11.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_11.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_11);
        

        
		// Adding items to the comboBox
		comboBox.addItem(null); // Represents the initial "Choose" option

		for (Visit v : Hospital.getInstance().getVisits().values()) {
		    if (v.getClass().equals(Visit.class)) {
		        comboBox.addItem(v.getNumber());
		    }
		}

		JButton btnNewButton = new JButton("Remove");
		btnNewButton.setBackground(SystemColor.inactiveCaption);
		btnNewButton.setForeground(SystemColor.inactiveCaptionBorder);
		btnNewButton.addActionListener(new ActionListener() {
		    
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        Integer selectedVisitNumber = (Integer) comboBox.getSelectedItem();
		        playSound("ss1.wav");
		        
		        if (selectedVisitNumber != null) {
		            if (Hospital.getInstance().removeVisit(Hospital.getInstance().getRealVisit(selectedVisitNumber))) {
		                JOptionPane.showMessageDialog(null, "Visit removed successfully.", 
		                        "Success", JOptionPane.INFORMATION_MESSAGE);
		                comboBox.removeItem(selectedVisitNumber);
		            }
		        } else {
		            JOptionPane.showMessageDialog(null, "Please choose a valid visit number.", 
		                    "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnNewButton.setBounds(397, 182, 153, 42);
		contentPane.add(btnNewButton);
		
		  // Main Button
        JButton mainButton = new JButton("Main");
        mainButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        mainButton.setBackground(SystemColor.text);
        mainButton.setForeground(SystemColor.activeCaption);
        mainButton.setBounds(822, 24, 101, 35);
        mainButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(mainButton);
		
	}
	 private void playSound(String soundFile) {
	        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
	        if (!soundFilePath.exists()) {
	            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
	            return;
	        }

	        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
	            AudioFormat format = audioIn.getFormat();
	            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
	                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
	                    Clip clip = AudioSystem.getClip();
	                    clip.open(audioIn);
	                    clip.start();
	                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
	                } else {
	                    System.err.println("Audio format not supported: " + format.toString());
	                }
	            } else {
	                System.err.println("Unsupported audio format: " + format.toString());
	            }
	        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
}
