package view;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Patient;
import model.Treatment;
import model.Visit;
import model.Medication;
import model.Disease;
import model.Fracture;
import model.Injury;
import model.MedicalProblem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DoctorMainpage extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Clip clip;

    public static void main(String[] args) {
        DoctorMainpage frame = new DoctorMainpage();
        frame.setVisible(true);
    }

    public DoctorMainpage() {
        setTitle("Doctor Main Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1023, 729);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption); // Matching background color
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Add logo image
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(0, 11, 289, 139); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        // Title
        JLabel lblTitle = new JLabel("Hi Doctor :)", JLabel.CENTER);
        lblTitle.setFont(new Font("Times New Roman", Font.BOLD, 45));
        lblTitle.setForeground(SystemColor.inactiveCaptionBorder);
        lblTitle.setBounds(233, 35, 500, 60);
        contentPane.add(lblTitle);

        JButton editInfoBtn = new JButton("SHOW/EDIT MY INFORMATION");
        editInfoBtn.setFont(new Font("Tahoma", Font.PLAIN, 22));
        editInfoBtn.setBounds(170, 163, 563, 60);
        editInfoBtn.setBackground(SystemColor.text);
        editInfoBtn.setForeground(SystemColor.activeCaption);
        editInfoBtn.addActionListener(e -> {
            playSound("ss1.wav");
            ShowMyData s = new ShowMyData();
            s.setVisible(true);
        });
        contentPane.add(editInfoBtn);

        JButton addTreatmentBtn = new JButton("Add Treatment to Medical Problem");
        addTreatmentBtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        addTreatmentBtn.setBounds(174, 234, 563, 50);
        addTreatmentBtn.setBackground(SystemColor.text);
        addTreatmentBtn.setForeground(SystemColor.activeCaption);
        addTreatmentBtn.addActionListener(e -> {
            playSound("ss1.wav");
            AddTreatmenttoMedProblem a = new AddTreatmenttoMedProblem();
            a.setVisible(true);
            setVisible(false);
        });
        contentPane.add(addTreatmentBtn);

        JButton addMedicationBtn = new JButton("Add Medication to Treatment");
        addMedicationBtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        addMedicationBtn.setBounds(174, 307, 563, 50);
        addMedicationBtn.setBackground(SystemColor.text);
        addMedicationBtn.setForeground(SystemColor.activeCaption);
        addMedicationBtn.addActionListener(e -> {
            playSound("ss1.wav");
            AddMedicationToTreatment A = new AddMedicationToTreatment();
            A.setVisible(true);
        });
        contentPane.add(addMedicationBtn);

        JButton addProblemAndTreatmentBtn = new JButton("Add Medical Problem and Treatment TO visit");
        addProblemAndTreatmentBtn.setFont(new Font("Tahoma", Font.PLAIN, 20));
        addProblemAndTreatmentBtn.setBounds(174, 379, 563, 50);
        addProblemAndTreatmentBtn.setBackground(SystemColor.text);
        addProblemAndTreatmentBtn.setForeground(SystemColor.activeCaption);
        addProblemAndTreatmentBtn.addActionListener(e -> {
            playSound("ss1.wav");
            AddMedProWTtoVISIT m = new AddMedProWTtoVISIT();
            m.setVisible(true);
        });
        contentPane.add(addProblemAndTreatmentBtn);

        JButton addAllBtn = new JButton("Add Medication");
        addAllBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
        addAllBtn.setBounds(174, 440, 172, 60);
        addAllBtn.setBackground(SystemColor.text);
        addAllBtn.setForeground(SystemColor.activeCaption);
        addAllBtn.addActionListener(e -> {
            playSound("ss1.wav");
            AddMedication m = new AddMedication();
            m.setVisible(true);
        });
        contentPane.add(addAllBtn);

        JButton viewDataBtn = new JButton("View Data");
        viewDataBtn.setFont(new Font("Tahoma", Font.PLAIN, 22));
        viewDataBtn.setBounds(170, 572, 563, 50);
        viewDataBtn.setBackground(SystemColor.text);
        viewDataBtn.setForeground(SystemColor.activeCaption);
        viewDataBtn.addActionListener(e -> {
            playSound("ss1.wav");
            showAllData();
        });
        contentPane.add(viewDataBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("Tahoma", Font.BOLD, 20));
        logoutBtn.setBounds(846, 20, 124, 50);
        logoutBtn.setBackground(SystemColor.inactiveCaption);
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder());
        logoutBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        logoutBtn.addActionListener(e -> {
            playSound("ss1.wav");
            setVisible(false);
            new login().setVisible(true);
        });
        contentPane.add(logoutBtn);

        // Additional buttons with similar design
        JButton btnNewButton = new JButton("ADD Medical Problem");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnNewButton.setBounds(356, 440, 204, 60);
        btnNewButton.setBackground(SystemColor.text);
        btnNewButton.setForeground(SystemColor.activeCaption);
        btnNewButton.addActionListener(e -> {
            playSound("ss1.wav");
            AddMedicalProblem m = new AddMedicalProblem();
            m.setVisible(true);
        });
        contentPane.add(btnNewButton);

        JButton btnNewButton_1 = new JButton("ADD Treatment");
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        btnNewButton_1.setBounds(570, 440, 167, 60);
        btnNewButton_1.setBackground(SystemColor.text);
        btnNewButton_1.setForeground(SystemColor.activeCaption);
        btnNewButton_1.addActionListener(e -> {
            playSound("ss1.wav");
            AddTreatment m = new AddTreatment();
            m.setVisible(true);
        });
        contentPane.add(btnNewButton_1);
        
        JButton btnNewButton_2 = new JButton("VISITS BEFORE DATE\r\n");
        btnNewButton_2.setBackground(SystemColor.text);
        btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 19));
        btnNewButton_2.setForeground(SystemColor.activeCaption);
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		howmanyvisitsbefore b = new	howmanyvisitsbefore();
        		b.setVisible(true);
        		
        	}
        });
        btnNewButton_2.setBounds(170, 516, 227, 45);
        contentPane.add(btnNewButton_2);
        
        JButton btnNewButton_3 = new JButton("COUNT MEDICATION");
        btnNewButton_3.setBackground(SystemColor.text);
        btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 19));
        btnNewButton_3.setForeground(SystemColor.activeCaption);
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		countmedication C = new countmedication();
        		C.setVisible(true);
        	}
        });
        btnNewButton_3.setBounds(518, 519, 215, 42);
        contentPane.add(btnNewButton_3);
        
        JButton btnNewButton_4 = new JButton("INFO");
        btnNewButton_4.setBackground(SystemColor.text);
        btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_4.setForeground(SystemColor.activeCaption);
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Informations i = new Informations();
        		i.setVisible(true);
        	}
        });
        btnNewButton_4.setBounds(407, 515, 101, 45);
        contentPane.add(btnNewButton_4);

        setVisible(true);
    }

    public void showAllData() {
        StringBuilder data = new StringBuilder();

        data.append("\nPatients:\n");
        List<Patient> sortedPatients = new ArrayList<>(Hospital.getInstance().getPatients().values());
        Collections.sort(sortedPatients, Comparator.comparing(Patient::getId)); // Sorting by ID

        for (Patient patient : sortedPatients) {
            data.append(patient).append("\n");
        }

        data.append("\nVisits:\n");
        List<Visit> sortedVisits = new ArrayList<>(Hospital.getInstance().getVisits().values());
        Collections.sort(sortedVisits, Comparator.comparing(Visit::getNumber)); // Sorting visits by number

        for (Visit visit : sortedVisits) {
            data.append(visit).append("\n");
        }

        data.append("\nTreatments:\n");
        for (Treatment treatment : Hospital.getInstance().getTreatments().values()) {
            data.append(treatment).append("\n");
            data.append("  Medications: \n");
            for (Medication medication : treatment.getMedicationsList()) {
                data.append("    ").append(medication).append("\n");
            }
        }

        data.append("\nMedications:\n");
        for (Medication medication : Hospital.getInstance().getMedications().values()) {
            data.append(medication).append("\n");
        }

        data.append("\nInjuries:\n");
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problem instanceof Injury) {
                data.append(problem).append("\n");
            }
        }

        data.append("\nDiseases:\n");
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problem instanceof Disease) {
                data.append(problem).append("\n");
            }
        }

        data.append("\nFractures:\n");
        for (MedicalProblem problem : Hospital.getInstance().getMedicalProblems().values()) {
            if (problem instanceof Fracture) {
                data.append(problem).append("\n");
            }
        }

        JTextArea textArea = new JTextArea(data.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));
        JOptionPane.showMessageDialog(this, scrollPane, "View All Data", JOptionPane.INFORMATION_MESSAGE);
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
    
