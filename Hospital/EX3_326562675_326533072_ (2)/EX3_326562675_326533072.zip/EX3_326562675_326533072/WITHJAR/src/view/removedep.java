package view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import control.Hospital;
import model.Department;

public class removedep extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private Clip clip;

    public removedep() {
        setTitle("Remove Department");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1013, 731);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
        


        // Title
        JLabel lblNewLabel = new JLabel("Remove Department");
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setBounds(392, 45, 245, 35);
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        contentPane.add(lblNewLabel);

        // Instruction Label
        JLabel lblNewLabel_11 = new JLabel("Which department are you removing?");
        lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblNewLabel_11.setBounds(45, 133, 463, 48);
        contentPane.add(lblNewLabel_11);

        // ComboBox for Department Selection
        JComboBox<Integer> comboBox = new JComboBox<>();
        comboBox.setBounds(55, 198, 155, 35);
        for (Department d : Hospital.getInstance().getDepartments().values()) {
            if (d.getClass().equals(Department.class)) {
                comboBox.addItem(d.getNumber());
            }
        }
        contentPane.add(comboBox);

        // Remove Button
        JButton remove = new JButton("Remove");
        remove.setForeground(SystemColor.inactiveCaptionBorder);
        remove.setFont(new Font("Tahoma", Font.PLAIN, 20));
        remove.setBounds(253, 195, 135, 33);
        remove.setBackground(SystemColor.text);
        remove.setForeground(SystemColor.activeCaption);
        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                Integer depnum = (Integer) comboBox.getSelectedItem();
                if (depnum != null) {
                    if (Hospital.getInstance().removeDepartment(Hospital.getInstance().getRealDepartment(depnum))) {
                        JOptionPane.showMessageDialog(null, "Department removed successfully.",
                                "Success", JOptionPane.INFORMATION_MESSAGE);
                        comboBox.removeItem(depnum);
                        if (comboBox.getItemCount() > 0) {
                            comboBox.setSelectedIndex(0); // Set the first item as selected
                        } else {
                            // Handle the case where no items are left
                            JOptionPane.showMessageDialog(null, "No more departments to display.",
                                    "Info", JOptionPane.INFORMATION_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to remove the department.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No department selected.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });      contentPane.add(remove);


        // Main Button
        JButton btnNewButton = new JButton("Main");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton.setBounds(741, 32, 128, 35);
        btnNewButton.setBackground(SystemColor.text);
        btnNewButton.setForeground(SystemColor.activeCaption);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(btnNewButton);

        setVisible(true);
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    
}
