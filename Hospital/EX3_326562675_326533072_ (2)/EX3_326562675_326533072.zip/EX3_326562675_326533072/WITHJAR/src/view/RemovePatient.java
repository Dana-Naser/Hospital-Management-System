package view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.sound.sampled.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import control.Hospital;
import model.Patient;

public class RemovePatient extends JFrame implements Serializable {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private static Integer patientid = 0; // Changed to Integer

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                RemovePatient frame = new RemovePatient();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public RemovePatient() {
        setTitle("Remove Patient");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1006, 644);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        
        JLabel logoLabel = new JLabel();
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-14, 0, 277, 100); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);
        


        // Title
        JLabel lblNewLabel = new JLabel("Remove Patient");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setBounds(313, 38, 355, 42);
        contentPane.add(lblNewLabel);

        // Instructions
        JLabel lblNewLabel_11 = new JLabel("Which patient are you removing?");
        lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblNewLabel_11.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel_11.setBounds(99, 106, 443, 42);
        contentPane.add(lblNewLabel_11);

        // ComboBox for Patients
        JComboBox<Integer> comboBox = new JComboBox<>();
        comboBox.setBounds(494, 113, 262, 35);
        for (Patient p : Hospital.getInstance().getPatients().values()) {
            if (p.getClass().equals(Patient.class)) {
                comboBox.addItem(p.getId()); // Add Integer directly to comboBox
            }
        }
        contentPane.add(comboBox);

        // Remove Button
        JButton removeButton = new JButton("Remove");
        removeButton.setFont(new Font("Tahoma", Font.PLAIN, 25));
        removeButton.setBackground(SystemColor.text);
        removeButton.setForeground(SystemColor.activeCaption);
        removeButton.setBounds(389, 171, 153, 42);
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                patientid = (Integer) comboBox.getSelectedItem(); // Get selected Integer
                if (patientid != null && Hospital.getInstance().removePatient(Hospital.getInstance().getRealPatient(patientid))) {
                    JOptionPane.showMessageDialog(null, "Patient removed successfully.", 
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    comboBox.removeItem(patientid); // Remove Integer from comboBox
                    comboBox.setSelectedIndex(0);
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to remove Patient.", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        contentPane.add(removeButton);

        // Main Button
        JButton mainButton = new JButton("Main");
        mainButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        mainButton.setBackground(SystemColor.text);
        mainButton.setForeground(SystemColor.activeCaption);
        mainButton.setBounds(822, 24, 101, 35);
        mainButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                Admin a = new Admin();
                a.setVisible(true);
                setVisible(false);
            }
        });
        contentPane.add(mainButton);

        // ComboBox Action Listener
        comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                patientid = (Integer) comboBox.getSelectedItem();
            }
        });
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (format.getSampleSizeInBits() == 16 && format.getChannels() == 2 && format.getSampleRate() == 44100) {
                if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioIn);
                    clip.start();
                    Thread.sleep(clip.getMicrosecondLength() / 1000); // Wait for sound to finish
                } else {
                    System.err.println("Audio format not supported: " + format.toString());
                }
            } else {
                System.err.println("Unsupported audio format: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
