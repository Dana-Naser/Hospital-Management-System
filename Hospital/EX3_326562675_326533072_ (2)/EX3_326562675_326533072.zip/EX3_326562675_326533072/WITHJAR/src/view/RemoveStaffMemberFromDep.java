package view;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import control.Hospital;
import exceptions.ObjectDoesNotExist;
import model.Doctor;
import model.Nurse;
import model.Department;

public class RemoveStaffMemberFromDep extends JFrame implements Serializable {

    private JPanel contentPane;
    private JTextField staffIdField;
    private JComboBox<Department> departmentComboBox;
    private JComboBox<String> staffTypeComboBox;
    private Hospital hospital;

    public RemoveStaffMemberFromDep(Hospital hospital) {
        this.hospital = hospital;

        setTitle("Remove Staff Member from Department");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 790, 544);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        ImageIcon icon = new ImageIcon(login.class.getResource("/pic/LOgoEnd.png"));
        Image image = icon.getImage();
        Image scaledImage = image.getScaledInstance(289, 139, Image.SCALE_SMOOTH); // Scale the image
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblNewLabel_1 = new JLabel();
        lblNewLabel_1.setIcon(scaledIcon); // Set the scaled icon
        lblNewLabel_1.setBounds(-35, 0, 271, 76); // Adjust the bounds as needed
        contentPane.add(lblNewLabel_1);

        JLabel lblStaffType = new JLabel("Staff Type:");
        lblStaffType.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblStaffType.setForeground(SystemColor.inactiveCaptionBorder);
        lblStaffType.setBounds(268, 159, 107, 25);
        contentPane.add(lblStaffType);

        staffTypeComboBox = new JComboBox<>(new String[]{"Doctor", "Nurse"});
        staffTypeComboBox.setBounds(399, 163, 200, 25);
        contentPane.add(staffTypeComboBox);

        JLabel lblStaffId = new JLabel("Staff ID:");
        lblStaffId.setForeground(SystemColor.inactiveCaptionBorder);
        lblStaffId.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblStaffId.setBounds(268, 203, 80, 25);
        contentPane.add(lblStaffId);

        staffIdField = new JTextField();
        staffIdField.setBounds(399, 203, 200, 25);
        contentPane.add(staffIdField);
        staffIdField.setColumns(10);

        JLabel lblDepartmentId = new JLabel("Department:");
        lblDepartmentId.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblDepartmentId.setForeground(SystemColor.inactiveCaptionBorder);
        lblDepartmentId.setBounds(268, 253, 121, 25);
        contentPane.add(lblDepartmentId);

        departmentComboBox = new JComboBox<>();
        departmentComboBox.setBounds(399, 253, 200, 25);
        contentPane.add(departmentComboBox);

        // Populate department combo box
        for (Department department : hospital.getDepartments().values()) {
            departmentComboBox.addItem(department);
        }

        JButton removeButton = new JButton("Remove");
        removeButton.setForeground(SystemColor.inactiveCaptionBorder);
        removeButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        removeButton.setBackground(SystemColor.inactiveCaption);
        removeButton.setBounds(338, 328, 126, 45);
        contentPane.add(removeButton);

        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                removeStaffMemberFromDep();
            }
        });

        JButton backButton = new JButton("Main");
        backButton.setBackground(SystemColor.inactiveCaption);
        backButton.setForeground(SystemColor.inactiveCaptionBorder);
        backButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
        backButton.setBounds(638, 11, 93, 33);
        contentPane.add(backButton);
        
        JLabel lblNewLabel = new JLabel("RemoveStaff Member From Department");
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        lblNewLabel.setForeground(SystemColor.inactiveCaptionBorder);
        lblNewLabel.setBounds(228, 65, 371, 48);
        contentPane.add(lblNewLabel);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                playSound("ss1.wav");
                new Admin().setVisible(true);
                setVisible(false);
            }
        });
    }

    private void removeStaffMemberFromDep() {
        try {
            int staffId = Integer.parseInt(staffIdField.getText());
            Department department = (Department) departmentComboBox.getSelectedItem();
            String staffType = (String) staffTypeComboBox.getSelectedItem();

            if (staffType.equals("Doctor")) {
                Doctor doctor = (Doctor) hospital.getStaffMember(staffId);
                if (doctor == null) {
                    throw new ObjectDoesNotExist(staffId, "Doctor", null);
                }
                if (department == null) {
                    throw new ObjectDoesNotExist(department.getNumber(), "Department", null);
                }
                department.removeDoctor(doctor);
                JOptionPane.showMessageDialog(this, "Doctor removed from department successfully!");
            } else if (staffType.equals("Nurse")) {
                Nurse nurse = (Nurse) hospital.getStaffMember(staffId);
                if (nurse == null) {
                    throw new ObjectDoesNotExist(staffId, "Nurse", null);
                }
                if (department == null) {
                    throw new ObjectDoesNotExist(department.getNumber(), "Department", null);
                }
                department.removeNurse(nurse);
                JOptionPane.showMessageDialog(this, "Nurse removed from department successfully!");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid IDs.");
        } catch (ObjectDoesNotExist ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void playSound(String soundFile) {
        File soundFilePath = new File("C:\\Users\\NS TECH\\Downloads\\" + soundFile);
        if (!soundFilePath.exists()) {
            System.err.println("Sound file not found: " + soundFilePath.getAbsolutePath());
            return;
        }

        try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFilePath)) {
            AudioFormat format = audioIn.getFormat();
            if (AudioSystem.isLineSupported(new DataLine.Info(Clip.class, format))) {
                Clip clip = AudioSystem.getClip();
                clip.open(audioIn);
                clip.start();
                Thread.sleep(clip.getMicrosecondLength() / 1000);
            } else {
                System.err.println("Audio format not supported: " + format.toString());
            }
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Hospital hospital = Hospital.getInstance(); // Use singleton instance
        RemoveStaffMemberFromDep frame = new RemoveStaffMemberFromDep(hospital);
        frame.setVisible(true);
    }
}